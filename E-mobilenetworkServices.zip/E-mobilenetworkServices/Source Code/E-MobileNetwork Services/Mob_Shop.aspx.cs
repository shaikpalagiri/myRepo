﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Collections;

using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Web.UI.WebControls ;


public partial class Mob_Shop : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();
    ClsMob Mob = new ClsMob();


    protected void Page_Load(object sender, EventArgs e)
    {
        Conn = MdlCommon.DBConnect();
        if (!IsPostBack)
        {
            Table7.Visible = false;
            Table9.Visible = false;
            Tbl_Head.Visible = false;
            Img_Preview.Visible = false;
            Tbl_Details.Visible = false;
            Tbl_Buttons.Visible = false;
            string Str = "SELECT DISTINCT(MOB_MAKE) FROM MOB_SHOP";
            Pr_Fill_Combo(Conn, Str, Drp_Make);
        }
    }
    protected void Pr_Fill_Combo(SqlConnection Conn, string Str, DropDownList E)
    {
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        E.Items.Clear();
        ListItem SelItem = new ListItem();
        SelItem.Text = "Select";
        SelItem.Value = "Select";
        E.Items.Add(SelItem);
        while (Dr.Read())
        {
            ListItem NewItem = new ListItem();
            NewItem.Text = Dr[0].ToString();
            NewItem.Value = Dr[0].ToString();
            E.Items.Add(NewItem);
        }
        Dr.Close();
    }

    protected void LBtn_Home_Click(object sender, EventArgs e)
    {
        Response.Redirect("Index.aspx");
    }
    protected void Drp_Make_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        if (Drp_Make.SelectedItem.Text == "Select")
        {
            Drp_Model.Items.Clear();
            Drp_Model.Items.Add("Select");
            Pr_Clear_All();
            return;
        }
        string Str = "SELECT MOB_MODEL FROM MOB_SHOP WHERE MOB_MAKE = '" + Drp_Make.SelectedItem.Text + "'";
        Pr_Fill_Combo(Conn, Str, Drp_Model);
    }

    private void Pr_Clear_All()
    {
        Txt_Make.Text = "";
        Txt_Model.Text = "";
        Txt_Cost.Text = "";
        Txt_Features.Text = "";
        Img_Preview.Visible = false;
        Table7.Visible = false;
        Table9.Visible = false;
    }

    protected  void Drp_Model_SelectedIndexChanged(System.Object sender, System.EventArgs e)
    {
        if (Drp_Model.SelectedItem.Text == "Select")
        {
            Pr_Clear_All();
            return;
        }
        if (Fn_View_Mob_Details() == false)
        {
            Obj.Pr_ASPNET_MessageBox("No Details Available for the Model you Selected");
            return;
        }
    }


    private bool Fn_View_Mob_Details()
    {
        bool functionReturnValue = false;
        string Str = "SELECT * FROM MOB_SHOP WHERE MOB_MAKE = '" + Drp_Make.SelectedItem.Text + "' AND MOB_MODEL = '" + Drp_Model.SelectedItem.Text + "'";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        functionReturnValue = false;
        while (Dr.Read())
        {
            Txt_Make.Text = Dr[1].ToString();
            Txt_Model.Text = Dr[2].ToString();
            Txt_Cost.Text = Dr[3].ToString();
            Txt_Features.Text = Dr[4].ToString();
            if (Dr[5] != "NO PIC")
            {
                Table7.Visible = true;
                Table9.Visible = false;
                Img_Preview.Visible = true;
                Img_Preview.ImageUrl = Dr[5].ToString();
                Table9.Visible = true;
            }
            else
            {
                Img_Preview.Visible = false;
                Table7.Visible = false;
                Table9.Visible = true;
            }
            functionReturnValue = true;
        }
        Dr.Close();
        return functionReturnValue;
    }


    protected void Btn_Upload_Click(object sender, EventArgs e)
    {

        if (Drp_Make.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Mobile Make");
            return;
        }
        if (Drp_Model.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Model No");
            return;
        }
        Tbl_Details.Visible = true;
        Tbl_Buttons.Visible = true;
        Tbl_Head.Visible = true;
        Btn_Upload.Enabled = false;
    }

    protected void Btn_Cancel1_Click(object sender, EventArgs e)
    {
        Btn_Upload.Enabled = true;
        Table7.Visible = false;
        Table9.Visible = false;
        Img_Preview.Visible = false;
        Drp_Make.ClearSelection();
        Drp_Model.Items.Clear();
        Drp_Model.Items.Add("Select");
        Txt_Make.Text = "";
        Txt_Model.Text = "";
        Txt_Features.Text = "";
        Txt_Cost.Text = "";
        Pr_Text_Clear();
        Tbl_Details.Visible = false;
        Tbl_Buttons.Visible = false;
        Tbl_Head.Visible = false;
    }
   


    protected void Btn_Register_Click(object sender, EventArgs e)
    {

        if (Fn_Validations() == true)
        {
            return;
        }
        string[] Val = new string[12];
        Pr_Fill_Values(Val);
        if (Mob.Fn_Save_Mob_Phone_Book(Conn, Val) == true)
        {
            Obj.Pr_ASPNET_MessageBox("Your Booking has been Submitted to Administrator");
            Pr_Invisible();
        }
        else
        {
            Obj.Pr_ASPNET_MessageBox("Error, Please Try Again");
        }
    }
    private void Pr_Invisible()
    {
        Btn_Upload.Enabled = true;
        Tbl_Head.Visible = false;
        Tbl_Details.Visible = false;
        Tbl_Buttons.Visible = false;
        Pr_Text_Clear();
        Tbl_Details.Visible = false;
        Tbl_Buttons.Visible = false;
        Tbl_Head.Visible = false;
    }

    private void Pr_Text_Clear()
    {
        Txt_FullName.Text = "";
        Txt_Address.Text = "";
        Txt_Age.Text = "";
        Drp_Gender.ClearSelection();
        Txt_Contact_No.Text = "";
        Txt_Mail.Text = "";
    }


    private void Pr_Fill_Values(string[] Val)
    {
        Val[0] = Obj.Fn_Sequence_Table("SEQ_MOB_BOOK", Conn).ToString();
      Val[1]= Strings.Trim(Strings.UCase(Txt_FullName.Text));
       Val[2] = Strings.Trim(Strings.UCase(Txt_Address.Text));
       Val[3] = Strings.Trim(Txt_Age.Text);
        Val[4] = Strings.UCase(Drp_Gender.SelectedItem.Text);
       Val[5] = Strings.Trim(Txt_Contact_No.Text);
        Val[6] = Strings.Trim(Txt_Mail.Text);
       Val[7] = Strings.Trim(Strings.UCase(Txt_Make.Text));
       Val[8] = Strings.Trim(Strings.UCase(Txt_Model.Text));
       Val[9] = Strings.Trim(Txt_Cost.Text);
        Val[10] = DateAndTime.Day(DateAndTime.Now) + "-" + DateAndTime.Month(DateAndTime.Now) + "-" + DateAndTime.Year(DateAndTime.Now);
       Val[11] = "PENDING";
    }

    private bool Fn_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_FullName.Text) | Obj.Fn_Check_Characters(Txt_FullName) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Name");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Address.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Address");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Age.Text) | Obj.Fn_Check_Numbers(Txt_Age) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Age");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Contact_No.Text) | Obj.Fn_Check_Numbers(Txt_Contact_No) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Contact No");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (Drp_Gender.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Gender");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Mail.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Enter your Email ID");
            functionReturnValue = true;
            return functionReturnValue;
        }
        return functionReturnValue;
    }


   
}