﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualBasic;

public partial class Post_Paid : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();
    string[] Acc = new string[7];
    ClsMob Mob = new ClsMob();
    private void Page_Load(System.Object sender, System.EventArgs e)
    {
  Conn= MdlCommon.DBConnect();
        if (!IsPostBack)
        {
            string Str = "SELECT * FROM POST_PAID_PROVIDERS ORDER BY PROVIDER_NAME ASC";
            Mob.Pr_Fill_Combo_Providers(Conn, Str,ref  Drp_Provider);
            Pr_Read_Only();
        }
    }

    private void Pr_Read_Only()
    {
        Txt_FullName.ReadOnly = true;
        Txt_Address.ReadOnly = true;
        Txt_Contact_No.ReadOnly = true;
        Txt_Age.ReadOnly = true;
        Drp_Gender.Enabled = false;
    }

    private void Pr_Enable()
    {
        Txt_FullName.ReadOnly = false;
        Txt_Address.ReadOnly = false;
        Txt_Contact_No.ReadOnly = false;
        Txt_Age.ReadOnly = false;
        Drp_Gender.Enabled = true;
    }
    public void Drp_Provider_SelectedIndexChanged(System.Object sender, System.EventArgs e)
    {
        if (Drp_Provider.SelectedItem.Text == "Select")
        {
            DGrid_View_Mob.Visible = false;
            Label1.Visible = false;
            return;
        }
        Label1.Visible = true;
        Label1.Text = "List of Post Paid Numbers Available in " + Drp_Provider.SelectedItem.Text + "";
        string Str = "SELECT MOB_NUM FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "' AND STATUS = 'NB'";
        DGrid_View_Mob.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Mob);
        if (DGrid_View_Mob.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Post Paid Numbers Available for the Service you Selected");
            DGrid_View_Mob.Visible = false;
            return;
        }
        string Str1 = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
        Label2.Visible = true;
        DGrid_View_Plans.Visible = true;
        Label2.Text = "List of Post Paid Plans available in " + Drp_Provider.SelectedItem.Text + "";
        Obj.Pr_Bind_Grid(Conn, Str1, DGrid_View_Plans);
        if (DGrid_View_Plans.Rows .Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Post Paid Plans currently available for the Service you Selected");
            Pr_Invisible();
        }
    }

    private void Pr_Invisible()
    {
        DGrid_View_Plans.Visible = false;
        Label2.Visible = false;
    }
    

    
    
    protected  void Btn_Register_Click(System.Object sender, System.EventArgs e)
    {
        if (string.IsNullOrEmpty(Txt_Service.Text) | string.IsNullOrEmpty(Txt_Card_No.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Select Service Provider and a Post Paid Num from the List");
            return;
        }
        if (string.IsNullOrEmpty(Txt_Plan_Name.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Select a Post Paid Plan from the List Below");
            return;
        }
        if (Fn_Validations() == true)
        {
            return;
        }
        string[] Book = new string[10];
        Pr_Fill_Post_Booking(Book);

        if (Mob.Fn_Save_Post_Paid_Booking(Conn, Book) == true)
        {
                     
            Pr_Change_Status();
            Pr_Clear_Fields();
            Pr_Read_Only();
            Obj.Pr_ASPNET_MessageBox("Post Paid Card Booked SuccessFully");
            LinkButton1.Visible = true;
        }
        else
        {
            Obj.Pr_ASPNET_MessageBox("Booking UnsuccessFull, Please Try Again");
        }
    }

       private void Pr_Fill_Post_Booking(string[] Book)
    {
        Book[0] = Txt_FullName.Text.Trim().ToUpper();
        Book[1] = Txt_Address.Text.Trim().ToUpper().Replace("'", "''");
        Book[2] = Txt_Contact_No.Text.Trim();
        Book[3] = Txt_Age.Text.Trim();
        Book[4] = Drp_Gender.SelectedItem.Text.ToUpper();
        Book[5] = Txt_Service.Text.Trim().ToUpper();
        Book[6] = Txt_Card_No.Text.ToUpper();
        Book[7] = Txt_Plan_Name.Text.Trim().ToUpper();
        Book[8] = DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year;
        Book[9] = "PENDING";
    }

    private void Pr_Clear_Fields()
    {
        Txt_FullName.Text = "";
        Txt_Address.Text = "";
        Txt_Contact_No.Text = "";
        Txt_Age.Text = "";
        Drp_Gender.ClearSelection();
        Txt_Service.Text = "";
        Txt_Card_No.Text = "";
        Txt_Plan_Name.Text = "";
        DGrid_View_Mob.Visible = false;
        Drp_Provider.ClearSelection();
        Label1.Visible = false;
        Label2.Visible = false;
        DGrid_View_Plans.Visible = false;
    }

    private bool Fn_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_FullName.Text) | Obj.Fn_Check_Characters(Txt_FullName) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid UserName");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Address.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Address");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Contact_No.Text) | Obj.Fn_Check_Numbers(Txt_Contact_No) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Contact Number");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Age.Text) | Obj.Fn_Check_Numbers(Txt_Age) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Age");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (Drp_Gender.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Gender");
            functionReturnValue = true;
            return functionReturnValue;
        }
        return functionReturnValue;
    }

   
    private void Pr_Change_Status()
    {
        string StrUp = "UPDATE POST_PAID_NUMBERS SET STATUS = 'B' WHERE MOB_NUM = '" + Txt_Card_No.Text + "'";
        SqlCommand Cmd = new SqlCommand(StrUp, Conn);
        Cmd.ExecuteNonQuery();
    }




    protected void DGrid_View_Plans_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DGrid_View_Plans.PageIndex  = e.NewPageIndex;
        string Str = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Plans);

    }
    protected void DGrid_View_Plans_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = DGrid_View_Plans.SelectedIndex;
        Txt_Plan_Name.Text = DGrid_View_Plans.Rows[i].Cells[1].Text;
    }
    protected void DGrid_View_Mob_SelectedIndexChanged(object sender, EventArgs e)
    {
        Pr_Enable();
        int i = DGrid_View_Mob.SelectedIndex;
        Txt_Card_No.Text = DGrid_View_Mob.Rows[i].Cells[0].Text;
        Txt_Service.Text = Drp_Provider.SelectedItem.Text;
    }
   
    protected  void LBtn_Home_Click(System.Object sender, System.EventArgs e)
    {
        Response.Redirect("Index.aspx");
    }


    protected  void Btn_Clear_Click(System.Object sender, System.EventArgs e)
    {
        Pr_Clear_Fields();
        Pr_Read_Only();
    }

    protected void Txt_Crd2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DGrid_View_Mob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DGrid_View_Mob.PageIndex = e.NewPageIndex;
    }
}