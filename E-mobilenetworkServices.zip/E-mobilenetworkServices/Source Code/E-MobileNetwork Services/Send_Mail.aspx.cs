﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Net.Mail;


public partial class Send_Mail : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();

    ClsDb Obj = new ClsDb();
    protected  void Page_Load(System.Object sender, System.EventArgs e)
    {
  Conn =  MdlCommon.   DBConnect();
        if (!IsPostBack)
        {
            Lst_ID.Visible = false;
            Btn_Add.Visible = false;
        }
    }

    protected  void Btn_Send_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (Fn_Validations() == true)
            {
                return;
            }
    

            MailMessage Mails = new MailMessage();
            Mails.From = new MailAddress( Txt_From.Text);
            string toEmailAddr = Txt_To.Text ;
string[] addrArray = toEmailAddr.Split(';');
foreach (string emailAddr in addrArray) {
    Mails.To.Add(new MailAddress(emailAddr));
}
               Mails.Subject = Txt_Sub.Text;
            Mails.Body = Txt_Body.Text;
            SmtpClient mSmtpClient = new SmtpClient();
            mSmtpClient.Host = System.Net.Dns.GetHostName();
            mSmtpClient.Send(Mails);
            Obj.Pr_ASPNET_MessageBox("Message Sent SuccessFully");
            Pr_Clear();
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    private void Pr_Clear()
    {
        Lst_ID.Visible = false;
        Btn_Add.Visible = false;
        Txt_To.Text = "";
        Txt_Sub.Text = "";
        Txt_Body.Text = "";
    }

    private bool Fn_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_To.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Enter Recepient Mail ID");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Sub.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Enter the Subject for your Mail");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Body.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Enter the Message");
            functionReturnValue = true;
            return functionReturnValue;
        }
        return functionReturnValue;
    }

    protected  void Btn_cancel_Click(System.Object sender, System.EventArgs e)
    {
        Pr_Clear();
    }

    protected  void LBtn_Add_To_List_Click(System.Object sender, System.EventArgs e)
    {
        string Str = "SELECT EMAIL_ID FROM USER_DETAILS";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        Lst_ID.Visible = true;
        Btn_Add.Visible = true;
        Txt_To.Text = "";
        while (Dr.Read())
        {
            Lst_ID.Items.Add(Dr[0].ToString());
        }
        Dr.Close();
    }

    protected  void Btn_Add_Click(System.Object sender, System.EventArgs e)
    {
        int i = 0;
        int Cnt = 0;
        //Txt_To.Text = ""
        for (i = 0; i <= Lst_ID.Items.Count - 1; i++)
        {
            if (Lst_ID.Items[i].Selected == true)
            {
                Cnt = Cnt + 1;
                if (string.IsNullOrEmpty(Txt_To.Text))
                {
                    Txt_To.Text = Lst_ID.Items[i].Text;
                }
                else
                {
                    Txt_To.Text = Txt_To.Text + ";" + Lst_ID.Items[i].Text;
                }
            }
        }
        if (Cnt == 0)
        {
            Obj.Pr_ASPNET_MessageBox("Please select a Mail ID");
        }
    }

    protected  void LBtn_Add_All_Click(System.Object sender, System.EventArgs e)
    {
        string Str = "SELECT EMAIL_ID FROM USER_DETAILS";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        Txt_To.Text = "";
        Lst_ID.Visible = false;
        Btn_Add.Visible = false;
        Txt_To.Text = "";
        while (Dr.Read())
        {
            if (string.IsNullOrEmpty(Txt_To.Text))
            {
                Txt_To.Text = Dr[0].ToString();
            }
            else
            {
                Txt_To.Text = Txt_To.Text + ";" + Dr[0];
            }
        }
        Dr.Close();
    }





    
}