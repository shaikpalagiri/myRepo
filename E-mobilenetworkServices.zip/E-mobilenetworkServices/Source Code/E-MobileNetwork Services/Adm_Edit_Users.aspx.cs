﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Adm_Edit_Users : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();
    protected void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
     Conn=    MdlCommon.   DBConnect();
            if (!IsPostBack)
            {
                Lbl_Status.Text = "1";
                string StrAll = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
                Pr_Bind_Grid(StrAll);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected void Btn_Search_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(Txt_Search_Name.Text))
            {
                Obj.Pr_ASPNET_MessageBox("Enter Name to Search");
                return;
            }
            //Dim Name As String = Trim(UCase(Txt_Search_Name.Text)) & "%"
            Lbl_Status.Text = "2";
            string Strname = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
            Pr_Bind_Grid(Strname);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    //Procedure to bind the DataGrid

    private void Pr_Bind_Grid(string Str)
    {
        DGrid_Edit.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Edit);
        if (DGrid_Edit.Rows .Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Customer's record found");
            DGrid_Edit.Visible = false;
        }
    }

    protected void DGrid_Edit_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
    {
        try
        {
            DGrid_Edit.EditIndex  = e.Item.ItemIndex;
            string Str = null;
            if (Lbl_Status.Text == "1")
            {
                Str = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
            }
            else
            {
                Str = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
            }
            Pr_Bind_Grid(Str);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    //protected void DGrid_Edit_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
    //{
    //    try
    //    {
    //        DGrid_Edit.EditItemIndex = -1;
    //        string Str = null;
    //        if (Lbl_Status.Text == "1")
    //        {
    //            Str = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
    //        }
    //        else
    //        {
    //            Str = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
    //        }
    //        Pr_Bind_Grid(Str);
    //    }
    //    catch (Exception ex)
    //    {
    //        Obj.Pr_ASPNET_MessageBox(ex.Message);
    //    }
    //}

   // protected void DGrid_Edit_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
   // {
    //    try
    //    {
    //        string[] StrUpdate = new string[2];
    //        int i = e.Item.ItemIndex;
    //        string NewAddress = null;
    //        string NewMob = null;
    //        string NewService = null;
    //        string NewBank = null;
    //        string NewAcc = null;
    //        string NewCredit = null;
    //        NewAddress = Strings.Replace(((TextBox)e.Item.Cells[2].Controls[0]).Text, "'", "''");
    //        NewMob = ((TextBox)e.Item.Cells[3].Controls[0]).Text;
    //        NewService = ((TextBox)e.Item.Cells[4].Controls[0]).Text;
    //        NewBank = ((TextBox)e.Item.Cells[5].Controls[0]).Text;
    //        NewAcc = ((TextBox)e.Item.Cells[6].Controls[0]).Text;
    //        NewCredit = ((TextBox)e.Item.Cells[7].Controls[0]).Text;
    //        if (string.IsNullOrEmpty(Strings.Trim(NewAddress)))
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter address of the customer");
    //            return;
    //        }
    //        if (string.IsNullOrEmpty(((TextBox)e.Item.Cells[3].Controls[0]).Text) | Obj.Fn_Check_Numbers((TextBox)e.Item.Cells[3].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid Mobile No");
    //            return;
    //        }
    //        if (string.IsNullOrEmpty(((TextBox)e.Item.Cells[4].Controls[0]).Text) | Obj.Fn_Check_Characters((TextBox)e.Item.Cells[4].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid service provider name");
    //            return;
    //        }
    //        string Str = "SELECT MOB_NUM FROM SERVICE_NUMBERS WHERE PROVIDER_NAME = '" + ((TextBox)e.Item.Cells[4].Controls[0]).Text + "'";
    //        if (Obj.Fn_Check_Mob_Number(Conn, Str, (TextBox)e.Item.Cells[3].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("This is not a Valid " + Strings.UCase(NewService) + " Number, Please Try Again");
    //            return;
    //        }
    //        if (string.IsNullOrEmpty(((TextBox)e.Item.Cells[5].Controls[0]).Text) | Obj.Fn_Check_Characters((TextBox)e.Item.Cells[5].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid bank name");
    //            return;
    //        }
    //        if (string.IsNullOrEmpty(((TextBox)e.Item.Cells[6].Controls[0]).Text) | Obj.Fn_Check_Numbers((TextBox)e.Item.Cells[6].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid Account No");
    //            return;
    //        }
    //        if (string.IsNullOrEmpty(Strings.Trim(NewCredit)))
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card Number");
    //            return;
    //        }
    //        if (Mob.Fn_Check_Credit_Card_No((TextBox)e.Item.Cells[7].Controls[0]) == false)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card No");
    //            return;
    //        }
    //        if (Strings.Len(NewCredit) < 16)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Credit Card No Must Contain 16 Digits");
    //            return;
    //        }
    //        StrUpdate[0] = "UPDATE USER_DETAILS SET ADDRESS = '" + Strings.Trim(Strings.UCase(NewAddress)) + "',MOBILE_NO = " + Strings.Trim(NewMob) + ",SERVICE_NAME = '" + Strings.Trim(Strings.UCase(NewService)) + "' WHERE USER_DET_ID = " + DGrid_Edit.Items(i).Cells(0).Text + "";
    //        StrUpdate[1] = "UPDATE USER_ACCOUNTS SET BANK_NAME = '" + Strings.Trim(Strings.UCase(NewBank)) + "', ACC_NO = " + Strings.Trim(NewAcc) + ", CREDIT_CARD_NO = '" + Strings.Trim(NewCredit) + "' WHERE USER_ACC_ID = " + DGrid_Edit.Items(i).Cells(0).Text + "";
    //        if (Obj.Fn_Execute_Query(Conn, StrUpdate) == true)
    //        {
    //            Obj.Pr_ASPNET_MessageBox("Customer Details updated successfully");
    //            DGrid_Edit.EditItemIndex = -1;
    //            string StrAll = null;
    //            if (Lbl_Status.Text == "1")
    //            {
    //                StrAll = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
    //            }
    //            else
    //            {
    //                StrAll = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
    //            }
    //            Pr_Bind_Grid(StrAll);
    //        }
    //        else
    //        {
    //            Obj.Pr_ASPNET_MessageBox(MdlCommon. MsgStr);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Obj.Pr_ASPNET_MessageBox(ex.Message);
    //    }
    //}

    protected void DGrid_Edit_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
    {
        //try
        //{
        //    DGrid_Edit.CurrentPageIndex = e.NewPageIndex;
        //    string Str = null;
        //    if (Lbl_Status.Text == "1")
        //    {
        //        Str = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
        //    }
        //    else
        //    {
        //        Str = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
        //    }
        //    Pr_Bind_Grid(Str);
        //}
        //catch (Exception ex)
        //{
        //    Obj.Pr_ASPNET_MessageBox(ex.Message);
        //}
    }

    protected  void LBtn_View_All_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            Lbl_Status.Text = "1";
            string StrAll = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
            Pr_Bind_Grid(StrAll);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }





    protected void DGrid_Edit_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void DGrid_Edit_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
         try
        {
            string[] StrUpdate = new string[2];
            int i =e.RowIndex ;
            string NewAddress = null;
            string NewMob = null;
            string NewService = null;
            string NewBank = null;
            string NewAcc = null;
            string NewCredit = null;
            GridViewRow row = DGrid_Edit.SelectedRow;
            NewAddress = Strings.Replace(((TextBox)row.Controls[0]).Text, "'", "''");
            NewMob = ((TextBox)row.Cells[3].Controls[0]).Text;
            NewService = ((TextBox)row.Cells[4].Controls[0]).Text;
            NewBank = ((TextBox)row.Cells[5].Controls[0]).Text;
            NewAcc = ((TextBox)row.Cells[6].Controls[0]).Text;
            NewCredit = ((TextBox)row.Cells[7].Controls[0]).Text;
            if (string.IsNullOrEmpty(Strings.Trim(NewAddress)))
            {
                Obj.Pr_ASPNET_MessageBox("Please enter address of the customer");
                return;
            }
            if (string.IsNullOrEmpty(((TextBox)row.Cells[3].Controls[0]).Text) | Obj.Fn_Check_Numbers((TextBox)row.Cells[3].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Mobile No");
                return;
            }
            if (string.IsNullOrEmpty(((TextBox)row.Cells[4].Controls[0]).Text) | Obj.Fn_Check_Characters((TextBox)row.Cells[4].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid service provider name");
                return;
            }
            string Str = "SELECT MOB_NUM FROM SERVICE_NUMBERS WHERE PROVIDER_NAME = '" + ((TextBox)row.Cells[4].Controls[0]).Text + "'";
            if (Obj.Fn_Check_Mob_Number(Conn, Str, (TextBox)row.Cells[3].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("This is not a Valid " + Strings.UCase(NewService) + " Number, Please Try Again");
                return;
            }
            if (string.IsNullOrEmpty(((TextBox)row.Cells[5].Controls[0]).Text) | Obj.Fn_Check_Characters((TextBox)row.Cells[5].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid bank name");
                return;
            }
            if (string.IsNullOrEmpty(((TextBox)row.Cells[6].Controls[0]).Text) | Obj.Fn_Check_Numbers((TextBox)row.Cells[6].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Account No");
                return;
            }
            if (string.IsNullOrEmpty(Strings.Trim(NewCredit)))
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card Number");
                return;
            }
            if (Mob.Fn_Check_Credit_Card_No((TextBox)row.Cells[7].Controls[0]) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card No");
                return;
            }
            if (Strings.Len(NewCredit) < 16)
            {
                Obj.Pr_ASPNET_MessageBox("Credit Card No Must Contain 16 Digits");
                return;
            }
            StrUpdate[0] = "UPDATE USER_DETAILS SET ADDRESS = '" + Strings.Trim(Strings.UCase(NewAddress)) + "',MOBILE_NO = " + Strings.Trim(NewMob) + ",SERVICE_NAME = '" + Strings.Trim(Strings.UCase(NewService)) + "' WHERE USER_DET_ID = " + DGrid_Edit.Rows[i].Cells[0].Text + "";
            StrUpdate[1] = "UPDATE USER_ACCOUNTS SET BANK_NAME = '" + Strings.Trim(Strings.UCase(NewBank)) + "', ACC_NO = " + Strings.Trim(NewAcc) + ", CREDIT_CARD_NO = '" + Strings.Trim(NewCredit) + "' WHERE USER_ACC_ID = " + DGrid_Edit.Rows[i].Cells[0].Text + "";
            if (Obj.Fn_Execute_Query(Conn, StrUpdate) == true)
            {
                Obj.Pr_ASPNET_MessageBox("Customer Details updated successfully");
                DGrid_Edit.EditIndex = -1;
                string StrAll = null;
                if (Lbl_Status.Text == "1")
                {
                    StrAll = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
                }
                else
                {
                    StrAll = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
                }
                Pr_Bind_Grid(StrAll);
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox(MdlCommon. MsgStr);
            }
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    protected void  DGrid_Edit_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
{
        try
        {
            DGrid_Edit.EditIndex = -1;
            string Str = null;
            if (Lbl_Status.Text == "1")
            {
                Str = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
            }
            else
            {
                Str = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
            }
            Pr_Bind_Grid(Str);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    protected void DGrid_Edit_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DGrid_Edit.PageIndex = e.NewPageIndex;
            string Str = null;
            if (Lbl_Status.Text == "1")
            {
                Str = "SELECT * FROM USER_DETAILS A, USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID";
            }
            else
            {
                Str = "SELECT * FROM USER_DETAILS A,USER_ACCOUNTS B WHERE A.USER_DET_ID = B.USER_ACC_ID AND A.FULL_NAME LIKE '" + Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%" + "'";
            }
            Pr_Bind_Grid(Str);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }




    protected void LinkButton2_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb1 = sender as LinkButton ;
        Response.Redirect (string.Format("AdminEditUsers.aspx?uid={0}", lb1.CommandArgument));
    }
    
    
}