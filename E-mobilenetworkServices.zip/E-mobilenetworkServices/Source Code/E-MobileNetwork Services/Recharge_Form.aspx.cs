﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class Recharge_Form : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();
    private void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
            //If Not IsPostBack Then
            //    If Session("PLAN") = "" Then
            //        Obj.Pr_ASPNET_MessageBox("Session Expired, Please Login Again")
            //        Exit Sub
            //    End If
            //End If
            Response.Expires = 0;
            Response.ExpiresAbsolute = DateAndTime.Now;
            Response.CacheControl = "no-cache";
           Conn= MdlCommon. DBConnect();
            if (!IsPostBack)
            {
                Label1.Text = Session["BALANCE"].ToString();
                if (Session["CHECK"] == "OWN")
                {
                    Txt_Service.Text = Session["SERVICE"].ToString();
                    Txt_Plan.Text = Session["PLAN"].ToString();
                    Txt_MobNo.Text = Session["MOB_NO"].ToString();
                }
                else if (Session["CHECK"] == "FRIEND")
                {
                    Txt_Service.Text = Session["SERVICE"].ToString();
                    Txt_Plan.Text = Session["PLAN"].ToString();
                    Txt_MobNo.Text = Session["FRND_MOB"].ToString();
                }
                Pr_Invisible_All();
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }



    private void Pr_Invisible_All()
    {
        Chk_Acc_Transfer.Checked = false;
        Chk_Credit_Card.Checked = false;
        Txt_Acc_No.Text = "";
        Txt_Crd1.Text = "";
        Txt_Crd2.Text = "";
        Txt_Crd3.Text = "";
        Txt_Crd4.Text = "";
        Txt_Name.Text = "";
        Txt_Pin_No.Text = "";
        Txt_Thro_Acc_Pin.Text = "";
        Txt_Thro_Acc_UserName.Text = "";
        Drp_Banks.ClearSelection();
        Drp_Thro_Acc_Banks.ClearSelection();
        Txt_Acc_No.Enabled = false;
        Txt_Crd1.Enabled = false;
        Txt_Crd2.Enabled = false;
        Txt_Crd3.Enabled = false;
        Txt_Crd4.Enabled = false;
        Txt_Name.Enabled = false;
        Txt_Pin_No.Enabled = false;
        Txt_Thro_Acc_Pin.Enabled = false;
        Txt_Thro_Acc_UserName.Enabled = false;
        Drp_Banks.Enabled = false;
        Drp_Thro_Acc_Banks.Enabled = false;
    }

    private bool Fn_Check_User_Holds_Credit_Card()
    {
        bool functionReturnValue = false;
        string Str = "SELECT CREDIT_CARD_NO FROM USER_ACCOUNTS WHERE USER_ACC_ID = " + Session["USER_ID"] + "";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        string Card = null;
        Dr = Cmd.ExecuteReader();
        while (Dr.Read())
        {
            Card = Dr[0].ToString();
            if (Card != "NO CARD")
            {
                functionReturnValue = true;
            }
            else
            {
                functionReturnValue = false;
            }
        }
        Dr.Close();
        return functionReturnValue;
    }

    private bool Fn_Account_Validations(string ChkStatus,  TextBox TName, TextBox TPin, DropDownList DBank)
    {
        bool functionReturnValue = false;
        string CreditCard = null;
        int PinNo = 0;
        string Str = "SELECT * FROM USER_ACCOUNTS WHERE USER_ACC_ID = " + Session["USER_ID"] + "";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        functionReturnValue = false;
        while (Dr.Read())
        {
            if (int.Parse(Session["CARD_COST"].ToString()) < int.Parse(Dr[6].ToString()))
            {
                if (Strings.Trim(Strings.UCase(TName.Text)) == Dr[1].ToString())
                {
                    if (Strings.UCase(DBank.SelectedItem.Text) == Dr[2].ToString())
                    {
                        if (TPin.Text == Dr[5].ToString())
                        {
                            if (ChkStatus == "CREDIT_CARD")
                            {
                                CreditCard = Txt_Crd1.Text + "-" + Txt_Crd2.Text + "-" + Txt_Crd3.Text + "-" + Txt_Crd4.Text;
                                if (CreditCard == Dr[4].ToString())
                                {
                                    functionReturnValue = true;
                                    break; // TODO: might not be correct. Was : Exit Do
                                }
                                else
                                {
                                    Obj.Pr_ASPNET_MessageBox("Invalid Credit Card Number");
                                    break; // TODO: might not be correct. Was : Exit Do
                                }
                            }
                            else
                            {
                                if (Txt_Acc_No.Text == Dr[3].ToString())
                                {
                                    functionReturnValue = true;
                                    break; // TODO: might not be correct. Was : Exit Do
                                }
                                else
                                {
                                    Obj.Pr_ASPNET_MessageBox("Invalid Account No");
                                    break; // TODO: might not be correct. Was : Exit Do
                                }
                            }
                        }
                        else
                        {
                            Obj.Pr_ASPNET_MessageBox("Invalid Pin No");
                            break; // TODO: might not be correct. Was : Exit Do
                        }
                    }
                    else
                    {
                        Obj.Pr_ASPNET_MessageBox("Invalid Bank Name");
                        break; // TODO: might not be correct. Was : Exit Do
                    }
                }
                else
                {
                    Obj.Pr_ASPNET_MessageBox("Invalid User Name");
                    break; // TODO: might not be correct. Was : Exit Do
                }
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox("Sorry, Your Account Balance is too Low");
                break; // TODO: might not be correct. Was : Exit Do
            }
        }
        Dr.Close();
        return functionReturnValue;
    }
    private bool Fn_Credit_Null_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_Name.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Invalid Name");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Pin_No.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Pin Number");
            return functionReturnValue;
        }
        if (Drp_Banks.SelectedItem.Text == "Select")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Select Bank");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Crd1.Text) | Strings.Len(Txt_Crd1.Text) < 4 | Obj.Fn_Check_Numbers(Txt_Crd1) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Invalid Credit Card Number");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Crd2.Text) | Strings.Len(Txt_Crd2.Text) < 4 | Obj.Fn_Check_Numbers(Txt_Crd2) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Invalid Credit Card Number");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Crd3.Text) | Strings.Len(Txt_Crd3.Text) < 4 | Obj.Fn_Check_Numbers(Txt_Crd3) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Invalid Credit Card Number");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Crd4.Text) | Strings.Len(Txt_Crd4.Text) < 4 | Obj.Fn_Check_Numbers(Txt_Crd4) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Invalid Credit Card Number");
            return functionReturnValue;
        }
        return functionReturnValue;
    }

    private bool Fn_Acc_Null_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_Acc_No.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Your Account No");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Thro_Acc_UserName.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Your Name");
            return functionReturnValue;
        }
        if (Drp_Thro_Acc_Banks.SelectedItem.Text == "Select")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Select Bank Name");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Thro_Acc_Pin.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Your Pin Number");
            return functionReturnValue;
        }
        return functionReturnValue;
    }


    protected void Btn_Recharge_Click(object sender, EventArgs e)
    {
        try
        {
            if (Chk_Acc_Transfer.Checked == false & Chk_Credit_Card.Checked == false)
            {
                Obj.Pr_ASPNET_MessageBox("Please select an appropriate recharge option");
                return;
            }
            string ChkStatus = null;
            if (Chk_Credit_Card.Checked == true)
            {
                ChkStatus = "CREDIT_CARD";
                if (Fn_Credit_Null_Validations() == true)
                {
                    return;
                }
                if (Fn_Account_Validations(ChkStatus, Txt_Name, Txt_Pin_No, Drp_Banks) == false)
                {
                    return;
                }
            }
            else if (Chk_Acc_Transfer.Checked == true)
            {
                ChkStatus = "ACC_TRANSFER";
                if (Fn_Acc_Null_Validations() == true)
                {
                    return;
                }
                if (Fn_Account_Validations(ChkStatus, Txt_Thro_Acc_UserName, Txt_Thro_Acc_Pin, Drp_Thro_Acc_Banks) == false)
                {
                    return;
                }
            }
            string[] Rchg = new string[13];
            Pr_Fill_Recharge_Details(Rchg);
            if (Mob.Fn_Save_User_Recharge_Details(Conn, Rchg) == true)
            {
                Pr_Invisible_All();
                Obj.Pr_ASPNET_MessageBox("Thank you for using TelecomServices.com, The Card Cost will be automatically debited from your account once recharged");
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox( MdlCommon. MsgStr);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }


    private void Pr_Fill_Recharge_Details(string[] Rchg)
    {
        Rchg[0] = Obj.Fn_Sequence_Table("SEQ_RCHG_ID", Conn);
        Rchg[1] = Session["USER_ID"].ToString();
        Rchg[2] = Session["FULL_NAME"].ToString();
        Rchg[3] = Session["MOB_NO"].ToString();
        if (Chk_Credit_Card.Checked == true)
        {
            Rchg[4] = Strings.Trim(Txt_Crd1.Text + "-" + Txt_Crd2.Text + "-" + Txt_Crd3.Text + "-" + Txt_Crd4.Text);
        }
        else
        {
            Rchg[4] = Strings.Trim(Txt_Acc_No.Text);
        }
        if (Session["CHECK"].ToString() == "OWN")
        {
            Rchg[5] = "OWN";
            Rchg[6] = "NIL";
            Rchg[7] = Strings.Trim(Txt_Service.Text);
            Rchg[8] = Strings.Trim(Txt_Plan.Text);
        }
        else
        {
            Rchg[5] = "FRIEND";
            Rchg[6] = Strings.Trim(Txt_MobNo.Text);
            Rchg[7] = Strings.Trim(Txt_Service.Text);
            Rchg[8] = Strings.Trim(Txt_Plan.Text);
        }
        Rchg[9] = DateAndTime.Year(DateAndTime.Now) + "/" + DateAndTime.Month(DateAndTime.Now) + "/" + DateAndTime.Day(DateAndTime.Now);
        Rchg[10] = Session["CARD_COST"].ToString();
        Rchg[11] = "PROCESSING";
        Rchg[12] = "";
    }

    protected void Btn_Cancel_Click(object sender, EventArgs e)
    {
        Pr_Invisible_All();
    }
    protected void LBtn_View_Plans_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Plans.aspx");
    }
    protected void LBtn_SignOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Index.aspx");

    }
    protected void Chk_Acc_Transfer_CheckedChanged(object sender, EventArgs e)
    {

        Pr_Invisible_All();
        Chk_Acc_Transfer.Checked = true;
        Txt_Acc_No.Enabled = true;
        Txt_Thro_Acc_Pin.Enabled = true;
        Txt_Thro_Acc_UserName.Enabled = true;
        Drp_Thro_Acc_Banks.Enabled = true;

    }
    protected void Chk_Credit_Card_CheckedChanged(object sender, EventArgs e)
    {
        Pr_Invisible_All();
        if (Fn_Check_User_Holds_Credit_Card() == false)
        {
            Obj.Pr_ASPNET_MessageBox("Sorry You dont have a Credit Card to Proceed with");
            return;
        }
        Chk_Credit_Card.Checked = true;
        Txt_Crd1.Enabled = true;
        Txt_Crd2.Enabled = true;
        Txt_Crd3.Enabled = true;
        Txt_Crd4.Enabled = true;
        Txt_Name.Enabled = true;
        Txt_Pin_No.Enabled = true;
        Drp_Banks.Enabled = true;
    }





    protected void LBtn_BlockMobileNos_Click(object sender, EventArgs e)
    {
        Response.Redirect("BlockMobileNos.aspx");
    }
}