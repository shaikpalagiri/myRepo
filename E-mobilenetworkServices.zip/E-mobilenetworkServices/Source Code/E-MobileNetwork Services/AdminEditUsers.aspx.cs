﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;



public partial class AdminEditUsers : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    SqlConnection Conn1 = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {   Conn = MdlCommon.DBConnect();
            Drp_Service.ClearSelection();
            string Str = "SELECT * FROM SERVICE_PROVIDERS";
            Mob.Pr_Fill_Combo_Providers(Conn, Str, ref Drp_Service);

            string getuser = string.Format("SELECT [USER_ACCOUNTS].[USER_ACC_ID],[USER_DETAILS].[ADDRESS],[USER_ACCOUNTS].[USERNAME],[USER_ACCOUNTS].[BANK_NAME] ,[USER_ACCOUNTS].[ACC_NO],[USER_ACCOUNTS].[CREDIT_CARD_NO] ,[USER_DETAILS].[MOBILE_NO] ,[USER_DETAILS].[SERVICE_NAME] FROM [USER_DETAILS],[USER_ACCOUNTS] WHERE [USER_DETAILS].[USER_DET_ID]=[USER_ACCOUNTS].[USER_ACC_ID] and  [USER_DETAILS].[USER_DET_ID]={0}", Request["uid"].ToString());

          //  string getuserdetails = string.Format("SELECT [USERNAME],[BANK_NAME],[ACC_NO],[CREDIT_CARD_NO] FROM [USER_ACCOUNTS] WHERE [USER_ACC_ID]={0}", Request["uid"].ToString());
         
            SqlCommand Cmd = new SqlCommand(getuser, Conn);
            SqlDataReader Dr = null;
            Dr = Cmd.ExecuteReader();
            while (Dr.Read())
            {
                Label1.Text = Dr["USERNAME"].ToString();
                txtBankName.Text = Dr["BANK_NAME"].ToString();
                txtaccno.Text = Dr["ACC_NO"].ToString();
                txtMobileNo.Text = Dr["MOBILE_NO"].ToString();
                txtadd.Text = Dr["ADDRESS"].ToString();
                Drp_Service.SelectedItem.Text = Dr["SERVICE_NAME"].ToString();
                string[] ccno;
                string ccnos = Dr["CREDIT_CARD_NO"].ToString();

                ccno = ccnos.Split('-');
                Txt_Crd1.Text = ccno[0].ToString();
                Txt_Crd2.Text = ccno[1].ToString();
                Txt_Crd3.Text = ccno[2].ToString();
                Txt_Crd4.Text = ccno[3].ToString();

                break; // TODO: might not be correct. Was : Exit Do
            }
        }
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }

private bool checkmobileno(string checkno)
{
   Conn1 = MdlCommon.DBConnect();
            SqlCommand Cmd = new SqlCommand(checkno, Conn1);
      int  res =int.Parse(Cmd.ExecuteScalar().ToString());
    if(res>=1)
            return true;
    return false;
}
    private bool ValidateMobileNo()
    {
      
        string Str = String.Format("SELECT count(*) FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Service.SelectedItem.Text + "' and Status='B' AND MOB_NUM='{0}'",txtMobileNo.Text );
        if (checkmobileno(Str)  == false)
        {
            Obj.Pr_ASPNET_MessageBox("This is not a Valid " + Drp_Service.SelectedItem.Text + " Number, Please Try Again");
            return false ;
        }
        if (string.IsNullOrEmpty(Strings.Trim(Txt_Crd1.Text)) || string.IsNullOrEmpty(Strings.Trim(Txt_Crd2.Text)) || string.IsNullOrEmpty(Strings.Trim(Txt_Crd3 .Text)) || string.IsNullOrEmpty(Strings.Trim(Txt_Crd4 .Text)) )
        {
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card Number");
            return false;
        }

        if (string.IsNullOrEmpty(Strings.Trim(txtBankName .Text)))
        {
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Bank Name ");
            return false;
        }

        if (string.IsNullOrEmpty(Strings.Trim(txtadd.Text)))
        {
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Address");
            return false;
        }
        if (Drp_Service.SelectedIndex==-1)
        {
            Obj.Pr_ASPNET_MessageBox("Please select the service provider");
            return false;
        }
        return true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ValidateMobileNo())
        {
            string[] User = new string[6];

        User[0]=txtMobileNo.Text;
            User[1]=txtBankName.Text;
            User[2]=txtadd.Text;
            User[3]=Drp_Service.SelectedItem.ToString();
            User[4]=txtaccno.Text;
            User[5]=string.Format("{0}-{1}-{2}-{3}",Txt_Crd1.Text,Txt_Crd2.Text,Txt_Crd3.Text,Txt_Crd4.Text);
            string updatequery = string.Format("UPDATE [USER_ACCOUNTS] SET [BANK_NAME] = '{0}',[ACC_NO] ='{1}',[CREDIT_CARD_NO] ='{2}' WHERE [USER_ACC_ID]={3}", User[1].ToString(), User[4].ToString(), User[5].ToString(), Request["uid"].ToString());
            Conn1 = MdlCommon.DBConnect();
            SqlCommand Cmd = new SqlCommand(updatequery, Conn1);
            Cmd.ExecuteNonQuery();
            string UpdateUserDetails = string.Format("UPDATE [USER_DETAILS] SET [ADDRESS] = '{0}',[MOBILE_NO] ='{1}' ,[SERVICE_NAME] = '{2}' WHERE [USER_DET_ID] = {3}", User[2].ToString(), User[0].ToString(), User[3].ToString(), Request["uid"].ToString());
            SqlCommand Cmd2 = new SqlCommand(UpdateUserDetails, Conn1);
            Cmd2.ExecuteNonQuery();


        }
    }
    protected void txtccno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Txt_Crd1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtadd_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtMobileNo_TextChanged(object sender, EventArgs e)
    {

    }
}