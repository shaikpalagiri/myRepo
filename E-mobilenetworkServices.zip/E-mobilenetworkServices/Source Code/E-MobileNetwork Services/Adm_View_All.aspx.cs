﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Adm_View_All : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();

    ClsDb Obj = new ClsDb();
    protected   void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
      Conn=   MdlCommon.DBConnect();
            if (!IsPostBack)
            {
                Drp_From_Year.Items.Clear();
                ListItem YearItem = new ListItem();
                YearItem.Text = "Select";
                YearItem.Value = "Select";
                Drp_From_Year.Items.Add(YearItem);
                for (int i = 1950; i <= DateTime.Now.Year; i += 1)
                {
                    ListItem NewItem = new ListItem();
                    NewItem.Text = i.ToString();
                    NewItem.Value = i.ToString();
                    Drp_From_Year.Items.Add(NewItem);
                }

                Drp_To_Year.Items.Clear();
                ListItem YearItem1 = new ListItem();
                YearItem1.Text = "Select";
                YearItem1.Value = "Select";
                Drp_To_Year.Items.Add(YearItem);
                for (int i = 1950; i <= DateTime.Now.Year; i += 1)
                {
                    ListItem NewItem = new ListItem();
                    NewItem.Text = i.ToString();
                    NewItem.Value = i.ToString();
                    Drp_To_Year.Items.Add(NewItem);
                }

                //Obj.Pr_Fill_Combo_Selected_Years(ref Drp_From_Year, 2012, 2000, -1);
                //Obj.Pr_Fill_Combo_Selected_Years(ref Drp_To_Year,2012, 2000, -1);
                Table14.Visible = false;
                string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE STATUS='PROCESSING'";
                Obj.Pr_Bind_Grid(Conn, Str, DGrid_Rchg_List);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected   void Btn_Search_Name_Click(System.Object sender, System.EventArgs e)
    {
        if (string.IsNullOrEmpty(Txt_Name.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Enter the Name to Search");
            return;
        }
        Session["SEARCH"] = "NAME";
        DGrid_Views.PageIndex = 0;
        string Name = Strings.Trim(Strings.UCase(Txt_Name.Text)) + "%";
        string Str = "SELECT * FROM USER_DETAILS A INNER JOIN USER_RECHARGE_DETAILS B ON A.USER_DET_ID = B.USER_RCHG_ID AND A.FULL_NAME LIKE '" + Name + "' AND B.STATUS='RECHARGED'";
        DGrid_Views.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Views);
        if (DGrid_Views.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Info Match Your Search");
            DGrid_Views.Visible = false;
        }
    }

   protected    void LinkBtn_View_All_Click(System.Object sender, System.EventArgs e)
    {
        Session["SEARCH"] = "ALL";
        DGrid_Views.PageIndex = 0;
        string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE STATUS='RECHARGED'";
        DGrid_Views.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Views);
        if (DGrid_Views.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Info Available");
            DGrid_Views.Visible = false;
        }
    }

  protected     void LinkBtn_View_Todays_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            Session["SEARCH"] = "TODAY";
            System.DateTime Tdate = DateAndTime.DateSerial(DateAndTime.Year(DateAndTime.Now), DateAndTime.Month(DateAndTime.Now), DateAndTime.Day(DateAndTime.Now));
            DGrid_Views.PageIndex = 0;
            //Dim Str As String = "SELECT * FROM USER_RECHARGE_DETAILS WHERE DAY(DATE_OF_RCHG)=" & Day(Now) & " AND MONTH(DATE_OF_RCHG)=" & Month(Now) & " AND YEAR(DATE_OF_RCHG)=" & Year(Now) & " AND STATUS='RECHARGED'"
            string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE DATE_OF_RCHG='" + Tdate + "'";
            // AND MONTH(DATE_OF_RCHG)=" & Month(Now) & " AND YEAR(DATE_OF_RCHG)=" & Year(Now) & " AND STATUS='RECHARGED'"
            DGrid_Views.Visible = true;
            Obj.Pr_Bind_Grid(Conn, Str, DGrid_Views);
            if (DGrid_Views.Rows.Count == 0)
            {
                Obj.Pr_ASPNET_MessageBox("No Info Available");
                DGrid_Views.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

   protected    void Btn_Search_Date_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (Drp_From_Day.SelectedIndex == 0 | Drp_From_Month.SelectedIndex == 0 | Drp_From_Year.SelectedIndex == 0)
            {
                Obj.Pr_ASPNET_MessageBox("Please select a valid from date");
                return;
            }
            if (Drp_To_Day.SelectedIndex == 0 | Drp_To_Month.SelectedIndex == 0 | Drp_To_Year.SelectedIndex == 0)
            {
                Obj.Pr_ASPNET_MessageBox("Please select a valid to date");
                return;
            }
            System.DateTime Fdate = default(System.DateTime);
            System.DateTime Tdate = default(System.DateTime);
            Fdate = DateAndTime.DateSerial(int.Parse(Drp_From_Year.SelectedItem.Text),int.Parse( Drp_From_Month.SelectedItem.Value), int.Parse(Drp_From_Day.SelectedItem.Text));
            Tdate = DateAndTime.DateSerial(int.Parse(Drp_To_Year.SelectedItem.Text), int.Parse(Drp_To_Month.SelectedItem.Value), int.Parse(Drp_To_Day.SelectedItem.Text));
            if (Fdate > Tdate)
            {
                Obj.Pr_ASPNET_MessageBox("Invalid date combination, Please check and try again");
                return;
            }
            Session["SEARCH"] = "DATE";
            DGrid_Views.PageIndex = 0;
            string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE DATE_OF_RCHG>='" + Fdate + "' AND DATE_OF_RCHG<='" + Tdate + "' AND STATUS='RECHARGED'";
            DGrid_Views.Visible = true;
            Obj.Pr_Bind_Grid(Conn, Str, DGrid_Views);
            if (DGrid_Views.Rows .Count == 0)
            {
                Obj.Pr_ASPNET_MessageBox("No Info available for the Specified Dates");
                DGrid_Views.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }


      protected  void DGrid_Rchg_List_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
    {
        DGrid_Rchg_List.PageIndex = e.NewPageIndex;
        string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE STATUS='PROCESSING'";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Rchg_List);
    }






            

     protected void DGrid_Rchg_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
     {
         try
         {
             string Str = null;
             DGrid_Views.PageIndex = e.NewPageIndex;
             if (Session["SEARCH"] == "DATE")
             {
                 System.DateTime Fdate = default(System.DateTime);
                 System.DateTime Tdate = default(System.DateTime);
                 Fdate = DateAndTime.DateSerial(int.Parse(Drp_From_Year.SelectedItem.Text), int.Parse(Drp_From_Month.SelectedItem.Value), int.Parse(Drp_From_Day.SelectedItem.Text));
                 Tdate = DateAndTime.DateSerial(int.Parse(Drp_To_Year.SelectedItem.Text), int.Parse(Drp_To_Month.SelectedItem.Value), int.Parse(Drp_To_Day.SelectedItem.Text));
                 Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE DATE_OF_RCHG>='" + Fdate + "' AND DATE_OF_RCHG<='" + Tdate + "' AND STATUS='RECHARGED'";
             }
             else if (Session["SEARCH"] == "NAME")
             {
                 string Name = Strings.Trim(Strings.UCase(Txt_Name.Text)) + "%";
                 Str = "SELECT * FROM USER_DETAILS A INNER JOIN USER_RECHARGE_DETAILS B ON A.USER_DET_ID = B.USER_RCHG_ID AND A.FULL_NAME LIKE '" + Name + "' AND STATUS='RECHARGED'";
             }
             else if (Session["SEARCH"] == "ALL")
             {
                 Str = "SELECT * FROM RECHARGED_LIST";
             }
             else if (Session["SEARCH"] == "TODAY")
             {
                 Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE DAY(DATE_OF_RCHG)=" + DateAndTime.Day(DateAndTime.Now) + " AND MONTH(DATE_OF_RCHG)=" + DateAndTime.Month(DateAndTime.Now) + " AND YEAR(DATE_OF_RCHG)=" + DateAndTime.Year(DateAndTime.Now) + " AND STATUS='RECHARGED'";
             }
             else
             {
                 return;
             }
             Obj.Pr_Bind_Grid(Conn, Str, DGrid_Views);
         }
         catch (Exception ex)
         {
             Obj.Pr_ASPNET_MessageBox(ex.Message);
         }
     }
     protected void DGrid_Rchg_List_SelectedIndexChanged(object sender, EventArgs e)
     {
            try
        {
            DataTable Dt = new DataTable();
            int i = 0;
            int ID = 0;
            i = DGrid_Rchg_List.SelectedIndex ;
            ID = int.Parse( DGrid_Rchg_List.Rows[i].Cells[0].Text);
            //Dt = Session("GRID")
            //Dt.Rows.RemoveAt(i)
            //DGrid_Rchg_List.DataSource = Dt
            //DGrid_Rchg_List.DataBind()
            //Dim Ins As String = "INSERT INTO RECHARGED_LIST SELECT * FROM USER_RECHARGE_DETAILS WHERE RCHG_ID = " & ID & ""
            //Call Pr_Inser_Delete(Ins)
            string[] StrUp = new string[2];
            StrUp[0] = "UPDATE USER_ACCOUNTS SET AVAIL_BAL = AVAIL_BAL - " + DGrid_Rchg_List.Rows [i].Cells[2].Text + " WHERE USER_ACC_ID = " + DGrid_Rchg_List.Rows[i].Cells[1].Text + "";
            StrUp[1] = "UPDATE USER_RECHARGE_DETAILS SET STATUS='RECHARGED',DATE_OF_RCHG='" + DateAndTime.Year(DateAndTime.Now) + "/" + DateAndTime.Month(DateAndTime.Now) + "/" + DateAndTime.Day(DateAndTime.Now) + "' WHERE RCHG_ID = " + ID + "";
            if (Obj.Fn_Execute_Query(Conn, StrUp) == true)
            {
                Obj.Pr_ASPNET_MessageBox("Recharge done successfully");
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox( MdlCommon. MsgStr);
                return;
            }
            string Str = "SELECT * FROM USER_RECHARGE_DETAILS WHERE STATUS='PROCESSING'";
            Obj.Pr_Bind_Grid(Conn, Str, DGrid_Rchg_List);
            if (DGrid_Rchg_List.Rows .Count == 0)
            {
                Obj.Pr_ASPNET_MessageBox("All Requests have been Completed Successfully");
                DGrid_Rchg_List.Visible = false;
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

     protected void DGrid_Views_PageIndexChanging(object sender, GridViewPageEventArgs e)
     {
         DGrid_Views.PageIndex = e.NewPageIndex;
     }
}