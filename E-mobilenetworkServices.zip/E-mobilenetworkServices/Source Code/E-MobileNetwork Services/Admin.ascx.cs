﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    
    protected void LBtn_Edit_Users_Click(object sender, EventArgs e)
    {
        Response.Redirect("Adm_Edit_Users.aspx");
    }
    protected void LBtn_Add_PostPaid_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Post_Paid.aspx");
    }
    protected void LBtn_View_Book_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_View_PP_Book.aspx");
    }
    protected void LBtn_View_Rchg_Click(object sender, EventArgs e)
    {
        Response.Redirect("Adm_View_All.aspx");
    }
    protected void LBtn_Send_Mail_Click(object sender, EventArgs e)
    {
        Response.Redirect("Send_Mail.aspx");
    }
    protected void LBtn_Mob_Shop_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Mob_Shopping.aspx");
    }
    protected void LBtn_SignOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
       
        Response.Expires = 0;
        Response.Redirect("Index.aspx");
       
    }
    protected void LBtn_View_MobileBlocking_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Mob_Blocking.aspx");
    }
}