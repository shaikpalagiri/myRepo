﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Web.UI.WebControls;



public partial class Admin_Post_Paid : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();

    protected void Page_Load(object sender, EventArgs e)
    {
        Conn = MdlCommon.DBConnect();
        if (!IsPostBack)
        {
            string Str = "SELECT * FROM POST_PAID_PROVIDERS ORDER BY PROVIDER_NAME ASC";
            Mob.Pr_Fill_Combo_Providers(Conn, Str, ref Drp_Provider);
            Btn_Register.Text = "Register";
            Tbl_Series.Visible = false;
        }
    }


    protected void LBtn_Delete_Click(object sender, EventArgs e)
    {
        try
        {
            if (Drp_Provider.SelectedItem.Text == "Select")
            {
                Obj.Pr_ASPNET_MessageBox("Select Service Name");
                return;
            }
            DGrid_View_Mob.Visible = false;
            Tbl_Series.Visible = false;
            string[] StrDelete = new string[3];
            StrDelete[0] = "DELETE FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
            StrDelete[1] = "DELETE FROM POST_PAID_PROVIDERS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
            StrDelete[2] = "DELETE FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "'";
            if (Obj.Fn_Execute_Query(Conn, StrDelete) == false)
            {
                Obj.Pr_ASPNET_MessageBox(MdlCommon.MsgStr);
            }
            string Str = "SELECT * FROM POST_PAID_PROVIDERS ORDER BY PROVIDER_NAME ASC";
            Mob.Pr_Fill_Combo_Providers(Conn, Str, ref  Drp_Provider);
            Obj.Pr_ASPNET_MessageBox("Connection Removed SuccessFully");
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    private void Pr_Fill_Provider(string[] Prov)
    {
        Prov[0] = Obj.Fn_Sequence_Table("SEQ_POST_PAID_PROVIDER", Conn);
        Prov[1] = Strings.Trim(Strings.UCase(Txt_Service_Name.Text));
    }


    protected void LBtn_Edit_Click(object sender, EventArgs e)
    {

        try
        {
            if (Drp_Provider.SelectedItem.Text == "Select")
            {
                Obj.Pr_ASPNET_MessageBox("Select Service Name");
                return;
            }
            string Str = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
            DGrid_Plans.Visible = true;
            DGrid_View_Mob.Visible = false;
            Pr_Text_Disabled();
            Obj.Pr_Bind_Grid(Conn, Str, DGrid_Plans);
            if (DGrid_Plans.Rows.Count == 0)
            {
                Obj.Pr_ASPNET_MessageBox("No Post Paid Plans Available for the Service you Selected");
                DGrid_Plans.Visible = false;
                Pr_Text_Enabled();
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }
    private void Pr_Text_Disabled()
    {
        Txt_Plan.Enabled = false;
        Txt_Plan_Value.Enabled = false;
        Txt_Outgoing.Enabled = false;
        Txt_Incoming.Enabled = false;
        Txt_SMS_Rate.Enabled = false;
    }

    private void Pr_Text_Enabled()
    {
        Txt_Plan.Enabled = true;
        Txt_Plan_Value.Enabled = true;
        Txt_Outgoing.Enabled = true;
        Txt_Incoming.Enabled = true;
        Txt_SMS_Rate.Enabled = true;
    }


    protected void LinkBtn_Add_Series_Click(object sender, EventArgs e)
    {

        if (Drp_Provider.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Provider Name");
            return;
        }
        DGrid_View_Mob.Visible = false;
        DGrid_Plans.Visible = false;
        Tbl_Series.Visible = true;
    }

    protected void LBtn_View_Nos_Click(object sender, EventArgs e)
    {

        if (Drp_Provider.SelectedItem.Text == "Select")
        {
            Obj.Pr_ASPNET_MessageBox("Select Service Name");
            return;
        }
        Tbl_Series.Visible = false;
        DGrid_Plans.Visible = false;
        string Str = "SELECT MOB_NUM FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "'";
        DGrid_View_Mob.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Mob);
        if (DGrid_View_Mob.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("Mobile Numbers Unavailable, Please Add the Series");
            DGrid_View_Mob.Visible = false;
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {

        if (string.IsNullOrEmpty(Txt_Series_From.Text) | string.IsNullOrEmpty(Txt_Series_To.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Series Number Text");
            return;
        }
        if (Strings.Len(Txt_Series_From.Text) < 10 | Strings.Len(Txt_Series_To.Text) < 10)
        {
            Obj.Pr_ASPNET_MessageBox("Mobile No Must Contain 10 Digit");
            return;
        }
        if ((long.Parse(Txt_Series_From.Text) > long.Parse(Txt_Series_To.Text)))
        {
            Obj.Pr_ASPNET_MessageBox("From Series must be Lesser than To Series");
            return;
        }

        string Str1 = null;
        for (long i = long.Parse(Txt_Series_From.Text); i <= long.Parse(Txt_Series_To.Text); i += 1)
        {
            if (Fn_Check_Mob_Number(i) == true)
            {
                Str1 = "INSERT INTO POST_PAID_NUMBERS VALUES('" + Drp_Provider.SelectedItem.Text + "'," + i + ",'NB')";
                SqlCommand Cmd1 = new SqlCommand(Str1, Conn);
                Cmd1.ExecuteNonQuery();
            }
        }
        Obj.Pr_ASPNET_MessageBox("Mobile Numbers Saved for the Connection - " + Drp_Provider.SelectedItem.Text + "");
        Txt_Series_From.Text = "";
        Txt_Series_To.Text = "";
        Drp_Provider.ClearSelection();
        Tbl_Series.Visible = false;
    }

    private bool Fn_Check_Mob_Number(long i)
    {
        bool functionReturnValue = false;
        string Str = "SELECT MOB_NUM FROM POST_PAID_NUMBERS WHERE MOB_NUM = '" + i + "'";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        functionReturnValue = true;
        while (Dr.Read())
        {
            functionReturnValue = false;
        }
        Dr.Close();
        return functionReturnValue;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Tbl_Series.Visible = false;
        Drp_Provider.ClearSelection();

    }
    protected void Btn_Register_Click(object sender, EventArgs e)
    {


        try
        {
            //If Fn_Validations() = True Then
            //    Exit Sub
            //End If
            if (Btn_Register.Text == "Register")
            {
                string[] Post = new string[6];
                Pr_Fill_Post_Paid_Plans(Post);
                if (Mob.Fn_Save_Post_Paid_Plans(Conn, Post) == true)
                {
                    Obj.Pr_ASPNET_MessageBox("Post Paid Plans Registered SuccessFully");
                }
                else
                {
                    Obj.Pr_ASPNET_MessageBox("Error, Please Try Again");
                    return;
                }
            }
            else if (Btn_Register.Text == "Update Plan")
            {
                string StrUp = "UPDATE POST_PAID_PLANS SET PLAN_NAME ='" + Strings.Trim(Strings.UCase(Txt_Plan.Text)) + "', PLAN_VALUE = " + Strings.Trim(Txt_Plan_Value.Text) + ", OUTGOING_RATE = '" + Strings.Trim(Txt_Outgoing.Text) + "', INCOMING_RATE = '" + Strings.Trim(Strings.UCase(Txt_Incoming.Text)) + "',SMS_RATE = " + Strings.Trim(Txt_SMS_Rate.Text) + " WHERE PLAN_NAME = '" + Session["PLAN"] + "'";
                SqlCommand Cmd = new SqlCommand(StrUp, Conn);
                Cmd.ExecuteNonQuery();
                Obj.Pr_ASPNET_MessageBox("Post Paid Plan of " + Drp_Provider.SelectedItem.Text + " Updated SuccessFully");
            }
            Pr_Clear_Fields();
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    private void Pr_Fill_Post_Paid_Plans(string[] Post)
    {
        Post[0] = Drp_Provider.SelectedItem.Value;
        Post[1] = Strings.Replace(Strings.Trim(Strings.UCase(Txt_Plan.Text)), "'", "''");
        Post[2] = Strings.Trim(Txt_Plan_Value.Text);
        Post[3] = Strings.Trim(Txt_Outgoing.Text);
        Post[4] = Strings.Trim(Strings.UCase(Txt_Incoming.Text));
        Post[5] = Strings.Trim(Strings.UCase(Txt_SMS_Rate.Text));
    }

    private void Pr_Clear_Fields()
    {
        Drp_Provider.ClearSelection();
        Txt_Plan.Text = "";
        Txt_Plan_Value.Text = "";
        Txt_Outgoing.Text = "";
        Txt_Incoming.Text = "";
        Txt_SMS_Rate.Text = "";
        DGrid_Plans.Visible = false;
        Btn_Register.Text = "Register";
        Pr_Text_Enabled();
    }


    protected void Btn_Clear_Click(object sender, EventArgs e)
    {
        Pr_Clear_Fields();
    }
    protected void Btn_Reg_Conn_Click(object sender, EventArgs e)
    {

        try
        {
            if (string.IsNullOrEmpty(Txt_Service_Name.Text))
            {
                Obj.Pr_ASPNET_MessageBox("Enter Provider Name");
                return;
            }
            string StrCon = "SELECT * FROM POST_PAID_PROVIDERS ORDER BY PROVIDER_NAME ASC";
            if (Mob.Fn_Check_Provider(Conn, StrCon, Txt_Service_Name) == false)
            {
                Obj.Pr_ASPNET_MessageBox("Provider Already Exists, Please Register a Different One");
                return;
            }
            string[] Prov = new string[2];
            Pr_Fill_Provider(Prov);
            if (Mob.Fn_Save_Post_Paid_Provider(Conn, Prov) == true)
            {
                Mob.Pr_Fill_Combo_Providers(Conn, StrCon, ref Drp_Provider);
                Txt_Service_Name.Text = "";
                Obj.Pr_ASPNET_MessageBox("Provider Added Successfully");
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox(MdlCommon.MsgStr);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }


    protected void Drp_Provider_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int i = 0;
            Pr_Text_Enabled();
            i = DGrid_Plans.SelectedIndex;
            Txt_Plan.Text = DGrid_Plans.Rows[i].Cells[1].Text;
            Session["PLAN"] = Txt_Plan.Text;
            Txt_Plan_Value.Text = DGrid_Plans.Rows[i].Cells[2].Text;
            Txt_Outgoing.Text = DGrid_Plans.Rows[i].Cells[3].Text;
            Txt_Incoming.Text = DGrid_Plans.Rows[i].Cells[4].Text;
            Txt_SMS_Rate.Text = DGrid_Plans.Rows[i].Cells[5].Text;
            Btn_Register.Text = "Update Plan";
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }


    protected void DGrid_Plans_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        int i = 0;
        i = e.RowIndex;

        string Plan = DGrid_Plans.Rows[i].Cells[1].Text;
        string[] StrDel = new string[1];
        StrDel[0] = "DELETE FROM POST_PAID_PLANS WHERE PLAN_NAME = '" + Plan + "'";
        if (Obj.Fn_Execute_Query(Conn, StrDel) == false)
        {
            Obj.Pr_ASPNET_MessageBox(MdlCommon.MsgStr);
        }
        string Str = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
        DGrid_Plans.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Plans);
        if (DGrid_Plans.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Post Paid Plans Available for the Service you Selected");
            DGrid_Plans.Visible = false;
        }
        Pr_Clear_Fields();
    }

    protected void DGrid_View_Mob_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = 0;
        i = DGrid_View_Mob.SelectedIndex;
        long No = long.Parse(DGrid_View_Mob.Rows[i].Cells[0].Text);
        string[] StrDel = new string[1];
        StrDel[0] = "DELETE FROM POST_PAID_NUMBERS WHERE MOB_NUM = '" + No + "'";
        if (Obj.Fn_Execute_Query(Conn, StrDel) == false)
        {
            Obj.Pr_ASPNET_MessageBox(MdlCommon.MsgStr);
        }
        string Str = "SELECT MOB_NUM FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "'";
        DGrid_View_Mob.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Mob);
        if (DGrid_View_Mob.Rows.Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("Mobile Numbers Unavailable, Please Add the Series");
            DGrid_View_Mob.Visible = false;
        }
    }

    protected void DGrid_View_Mob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        DGrid_View_Mob.PageIndex = e.NewPageIndex;
        string Str = "SELECT MOB_NUM FROM POST_PAID_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "'";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Mob);

    }
    protected void DGrid_View_Plans_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int i = 0;
            Pr_Text_Enabled();
            i = DGrid_Plans.SelectedIndex;
            Txt_Plan.Text = DGrid_Plans.Rows[i].Cells[1].Text;
            Session["PLAN"] = Txt_Plan.Text;
            Txt_Plan_Value.Text = DGrid_Plans.Rows[i].Cells[2].Text;
            Txt_Outgoing.Text = DGrid_Plans.Rows[i].Cells[3].Text;
            Txt_Incoming.Text = DGrid_Plans.Rows[i].Cells[4].Text;
            Txt_SMS_Rate.Text = DGrid_Plans.Rows[i].Cells[5].Text;
            Btn_Register.Text = "Update Plan";
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }
    protected void DGrid_View_Plans_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        DGrid_Plans.PageIndex = e.NewPageIndex;
        string Str = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID = " + Drp_Provider.SelectedItem.Value + "";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Plans);
    }

    protected void Txt_Service_Name_TextChanged(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
}