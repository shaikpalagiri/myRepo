﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class View_Plans : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();
    private void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
            Response.Expires = 0;
            Response.ExpiresAbsolute = DateAndTime.Now;
            Response.CacheControl = "no-cache";
          Conn=MdlCommon.DBConnect();
            if (!IsPostBack)
            {
                string Str = "SELECT * FROM POST_PAID_PROVIDERS";
                Tbl_Frnd_mob.Visible = false;
                Chk_Own.Checked = true;
                Session["CHECK"] = "OWN";
                Mob.Pr_Fill_Combo_Providers(Conn, Str, ref Drp_Provider);
                Pr_Get_User_Service_Name();
                Lbl_Name.Text = "Welcome " + Session["FULL_NAME"].ToString().ToUpper() + "&nbsp;";
                Lbl_Login.Text = "You are logged in as " + Session["USER_NAME"] + "&nbsp;";
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }
    private void Pr_Get_User_Service_Name()
    {
        int i =int.Parse( Session["USER_ID"].ToString());
        string StrSer = String.Format("SELECT B.SERVICE_NAME,B.MOBILE_NO FROM USER_LOGIN A INNER JOIN USER_DETAILS B ON A.USER_LOG_ID='{0}' AND B.USER_DET_ID='{0}' and MOBILE_NO NOT IN(SELECT MobileNo FROM USER_blockmobileno_requests where Status='Request' or Status='Accepted')", i);
     //   string StrSer = "SELECT B.SERVICE_NAME,B.MOBILE_NO FROM USER_LOGIN A INNER JOIN USER_DETAILS B ON A.USER_LOG_ID=" + i + " AND B.USER_DET_ID=" + i + "";
        SqlCommand Cmd = new SqlCommand(StrSer, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        while (Dr.Read())
        {
            Session["SERVICE"] = Dr[0];
            Session["MOB_NO"] = Dr[1];
        }
        Dr.Close();
    }

    //Function to get the user's available account balance

    private bool Fn_Get_Acc_Balance()
    {
        bool functionReturnValue = false;
        string Str = "SELECT AVAIL_BAL FROM USER_ACCOUNTS WHERE USER_ACC_ID = " + Session["USER_ID"] + "";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        while (Dr.Read())
        {
            if (int.Parse(Dr[0].ToString()) <= 1000)
            {
                functionReturnValue = false;
            }
            else
            {
                functionReturnValue = true;
                Session["BALANCE"] = Dr[0];
            }
        }
        Dr.Close();
        return functionReturnValue;
    }

    protected void Chk_Own_CheckedChanged(object sender, EventArgs e)
    {
        
			Chk_Frnd.Checked = false;
			Tbl_Frnd_mob.Visible = false;
			Drp_Provider.ClearSelection();
			DGrid_Plans.Visible = false;
			Session["FRND_MOB"] = "";
			Session["CHECK"] = "OWN";
			Pr_Get_User_Service_Name();
		}


    protected void Chk_Frnd_CheckedChanged(object sender, EventArgs e)
    {
        Chk_Own.Checked = false;
        Tbl_Frnd_mob.Visible = true;
        Drp_Provider.ClearSelection();
        DGrid_Plans.Visible = false;
        Session["SERVICE"] = "";
        Session["CHECK"] = "FRIEND";


    }
    protected void Drp_Provider_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Drp_Provider.SelectedItem.Text == "Select")
        {
            DGrid_Plans.Visible = false;
            return;
        }
        int i =int.Parse(Drp_Provider.SelectedItem.Value);
        string Str = "SELECT * FROM POST_PAID_PLANS WHERE PROVIDER_ID=" + i + "";
        DGrid_Plans.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Plans);
        if (DGrid_Plans.Rows .Count == 0)
        {
            Obj.Pr_ASPNET_MessageBox("No Plans Available");
            Drp_Provider.ClearSelection();
            DGrid_Plans.Visible = false;
        }
    }


    protected void DGrid_View_Plans_SelectedIndexChanged(object sender, EventArgs e)
    {
if (Fn_Get_Acc_Balance() == false) {
				Obj.Pr_ASPNET_MessageBox("Your Account Balance is Too Low, Sorry You Cant Recharge");
				return;
			}
			if (Chk_Frnd.Checked == true) {
				if (string.IsNullOrEmpty(Strings.Trim(Txt_Frnd_Mob.Text)) | Obj.Fn_Check_Numbers(Txt_Frnd_Mob) == false) {
					Obj.Pr_ASPNET_MessageBox("Please enter a valid friend mobile number");
					return;
				}
				string Str = "SELECT MOB_NUM FROM SERVICE_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Provider.SelectedItem.Text + "'";
				if (Obj.Fn_Check_Mob_Number(Conn, Str, Txt_Frnd_Mob) == false) {
					Obj.Pr_ASPNET_MessageBox("This is not a Valid " + Drp_Provider.SelectedItem.Text + " Number, Please Try Again");
					return;
				}
			}
			int i = 0;
            i = DGrid_Plans.SelectedIndex;
			Session["PLAN"] = DGrid_Plans.SelectedRow.Cells[0].Text;
            Session["CARD_COST"] = DGrid_Plans.SelectedRow.Cells[1].Text;
            try
            {
                if (Session["CHECK"].ToString() == "OWN")
                {
                    if (Drp_Provider.SelectedItem.Text != Session["SERVICE"].ToString())
                    {
                        Obj.Pr_ASPNET_MessageBox("Sorry, You can't Recharge with another Service, Please Select " + Session["SERVICE"] + "");
                        return;
                    }
                }
                else if (Session["CHECK"].ToString() == "FRIEND")
                {
                    Session["SERVICE"] = Drp_Provider.SelectedItem.Text;
                    Session["FRND_MOB"] = Strings.Trim(Txt_Frnd_Mob.Text);
                }
                Response.Redirect("Recharge_Form.aspx");
            }
            catch (Exception ex)
            {

                Obj.Pr_ASPNET_MessageBox("Sorry, You can't Recharge  ");
                return;
            }
		}

  
    protected void DGrid_View_Plans_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
    {
        DGrid_Plans.PageIndex = e.NewPageIndex;
        string Str = "SELECT * FROM SERVICE_PLANS_DETAILS WHERE SER_PLAN_ID=" + Drp_Provider.SelectedItem.Value + "";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Plans);

    }
    protected void LBtn_Change_Pwd_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Change_Password.aspx");
    }
    protected void LBtn_SignOut_Click(object sender, EventArgs e)
    {
          Session.Abandon();
        Response.Redirect("Index.aspx");
    }

    protected void LBtn_BlockMobileNos_Click(object sender, EventArgs e)
    {
        //Response.Redirect("BlockMobileNos.aspx");
    }
    
}