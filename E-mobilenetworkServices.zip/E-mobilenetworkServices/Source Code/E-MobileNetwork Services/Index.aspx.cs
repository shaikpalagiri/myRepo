﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Index : System.Web.UI.Page
{

    SqlConnection Conn = new SqlConnection();

    ClsDb Obj = new ClsDb();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        { 
           
            Conn = MdlCommon.DBConnect();
           
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }

    protected  void Btn_Login_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (ADMIN() == true)
            {
                Response.Redirect("Admin.aspx");
            }
            else if (Fn_Check_User_Login() == false)
            {
                Obj.Pr_ASPNET_MessageBox("Incorrect UserName or Password");
            }
            else
            {
                Response.Redirect("View_Plans.aspx");
            }
            //End If
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    private bool Fn_Check_User_Login()
    {
        
        bool functionReturnValue = false;
        try
        {
            string StrUser = "SELECT A.USER_LOG_ID,A.USER_LOG_NAME,A.USER_PASSWORD, B.FULL_NAME FROM USER_LOGIN A INNER JOIN USER_DETAILS B ON A.USER_LOG_ID=B.USER_DET_ID AND A.USER_LOG_NAME= '" + Strings.Trim(Txt_UserName.Text) + "' AND USER_PASSWORD = '" + Strings.Trim(Txt_Password.Text) + "'";
            SqlCommand Cmd = new SqlCommand(StrUser, Conn);
            SqlDataReader Dr = null;
            Dr = Cmd.ExecuteReader();
            functionReturnValue = false;
            while (Dr.Read())
            {
                Session["USER_ID"] = Dr[0];
                Session["USER_NAME"] = Dr[1];
                Session["FULL_NAME"] = Dr[3];
                functionReturnValue = true;
                break; // TODO: might not be correct. Was : Exit Do
            }
            Dr.Close();
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
        return functionReturnValue;
    }
    private bool ADMIN()
    {
        bool functionReturnValue = false;
        try
        {
            string StrUser1 = "SELECT * FROM ADMINLOG WHERE USERNAME= '" + Txt_UserName.Text + "'";
            SqlCommand Cmd1 = new SqlCommand(StrUser1, Conn);
            SqlDataReader Dr1 = null;
            Dr1 = Cmd1.ExecuteReader();
            while (Dr1.Read())
            {
                if (Txt_Password.Text == Dr1[1].ToString().Trim())
                {
                    functionReturnValue = true;
                }
            }
            Dr1.Close();
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
        return functionReturnValue;
    }

    protected void LBtn_PP_Book_Click(object sender, EventArgs e)
    {
        Response.Redirect("Post_Paid.aspx");
    }
    protected void LBtn_Mob_Shop_Click(object sender, EventArgs e)
    {
        Response.Redirect("Mob_Shop.aspx");
    }
   protected void Txt_UserName_TextChanged(object sender, EventArgs e)
    {

    }
    
}