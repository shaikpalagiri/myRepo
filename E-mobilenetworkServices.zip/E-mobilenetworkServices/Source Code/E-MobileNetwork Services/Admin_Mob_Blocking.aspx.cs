﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Admin_Mob_Blocking : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    protected void Page_Load(object sender, EventArgs e)
    {
        	Conn= MdlCommon.DBConnect();
			if (!IsPostBack) {
			Pr_Bind_Grid();
			}
		}
    protected void Pr_Bind_Grid()
    {
        string Str = "SELECT * FROM USER_BLOCKMOBILENO_REQUESTS WHERE STATUS = 'REQUEST'";
        DGrid_Mob_Shop.Visible = true;
        Txt_Mob_Search.Text = "";
        Lbl_Mob.Text = "1";
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Mob_Shop);
        if (DGrid_Mob_Shop.Rows.Count == 0)
        {
            DGrid_Mob_Shop.Visible = false;
            Txt_Mob_Search.Text = "";
        }
    }

    protected void Btn_Mob_Click(object sender, EventArgs e)
    {

    }
    protected void LBtn_View_Mob_Click(object sender, EventArgs e)
    {

    }
    protected void Txt_Mob_Search_TextChanged(object sender, EventArgs e)
    {

    }

    protected void DGrid_Mob_Shop_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        int i = DGrid_Mob_Shop.SelectedIndex;
        string StrAccepted = string.Format("UPDATE USER_BLOCKMOBILENO_REQUESTS   SET [status] = 'Accepted' ,ConfirmedOn=getdate() WHERE bmid={0}", DGrid_Mob_Shop.Rows[i].Cells[0].Text);
        SqlCommand Cmd = new SqlCommand(StrAccepted, Conn);
        Cmd.ExecuteNonQuery();
        string upquery = string.Format("UPDATE [POST_PAID_BOOKING]   SET [STATUS] = 'BLOCKED' WHERE  [USERNAME] = '{0}' and [POST_PAID_BOOKED_NUM] = '{1}'", DGrid_Mob_Shop.Rows[i].Cells[1].Text,DGrid_Mob_Shop.Rows[i].Cells[2].Text);
        Cmd = new SqlCommand(upquery, Conn);
        Cmd.ExecuteNonQuery();

        Obj.Pr_ASPNET_MessageBox("Mobile No is Blocked SuccessFully");
        Pr_Bind_Grid();
    }
    protected void DGrid_Mob_Shop_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int i = e.RowIndex;
            string StrDel = string.Format( "UPDATE USER_BLOCKMOBILENO_REQUESTS   SET [status] = 'Rejected' ,ConfirmedOn=getdate() WHERE bmid={0}", DGrid_Mob_Shop.Rows[i].Cells[0].Text);
            SqlCommand Cmd = new SqlCommand(StrDel, Conn);
            Cmd.ExecuteNonQuery();
            Obj.Pr_ASPNET_MessageBox("Mobile No Blocking Request is Rejected....");
            Pr_Bind_Grid();

        }
        catch (Exception Er)
        {
        }
    }

    protected void DGrid_Mob_Shop_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DGrid_Mob_Shop.PageIndex = e.NewPageIndex;
            string Str = null;
            if (Lbl_Mob.Text == "1")
            {
                Str = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING'";
            }
            else
            {
                string Name = Strings.Trim(Strings.UCase(Txt_Mob_Search.Text)) + "%";
                Str = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
            }
           // Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Booking);
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }
}