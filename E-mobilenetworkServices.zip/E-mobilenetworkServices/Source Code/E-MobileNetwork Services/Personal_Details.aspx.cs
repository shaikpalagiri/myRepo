﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class Personal_Details : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();
    protected  void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
        Conn=  MdlCommon.DBConnect();
            if (!IsPostBack)
            {
                Drp_Year.Items.Clear();
                ListItem YearItem = new ListItem();
                YearItem.Text = "Select";
                YearItem.Value = "Select";
                Drp_Year.Items.Add(YearItem);
                for (int i = 1950; i <= DateTime.Now.Year-18; i += 1)
                {
                    ListItem NewItem = new ListItem();
                    NewItem.Text = i.ToString();
                    NewItem.Value = i.ToString();
                    Drp_Year.Items.Add(NewItem);
                }

                //Int16  uu = Int16.Parse(DateTime.Now.Year.ToString());
                //int years = DateTime.Now.Year - 18;
                string Str = "SELECT * FROM POST_PAID_PROVIDERS";
               // Obj.Pr_Fill_Combo_Selected_Years(ref Drp_Year, years, 1950, -1);
                Mob.Pr_Fill_Combo_Providers(Conn, Str,  ref Drp_Service);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected  void Btn_Get_UserName_Click(System.Object sender, System.EventArgs e)
    {
        if (Fn_Validations() == true)
        {
            return;
        }
        string Str = "SELECT MOB_NUM FROM SERVICE_NUMBERS WHERE PROVIDER_NAME = '" + Drp_Service.SelectedItem.Text + "'";
        //If Obj.Fn_Check_Mob_Number(Conn, Str, Txt_MobNo) = False Then
        //    Obj.Pr_ASPNET_MessageBox("This is not a Valid " & Drp_Service.SelectedItem.Text & " Number, Please Try Again")
        //    Exit Sub
        //End If
        string Name = Strings.Trim(Strings.LCase(Txt_FullName.Text));
        int Day = int.Parse(Drp_Day.SelectedItem.Text);
        string Mon = Strings.LCase(Drp_Month.SelectedItem.Text);
        int Yr =int.Parse( Strings.Mid(Drp_Year.SelectedItem.Text, Strings.Len(Drp_Year.SelectedItem.Text) - 1, 2));
        Txt_UserName.Text = Strings.Mid(Name, 1, 3) + Day + Mon + Yr;
    }


    protected void Drp_Year_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Btn_Register_Click(object sender, EventArgs e)
    {
        try
        {
            string[] Login = new string[3];
            string[] User = new string[10];
            string[] Acc = new string[7];
            //If Fn_Login_Validations() = True Then
            //    Exit Sub
            //End If
            //If Fn_Validations() = True Then
            //    Exit Sub
            //End If
            Pr_Login_Details(Login);
            Pr_Fill_User_Details(User);
            Pr_Acc_Details(Acc);
            string[] StrUser = new string[4];
            StrUser[0] = "INSERT INTO USER_LOGIN VALUES(" + Login[0] + ",'" + Login[1] + "','" + Login[2] + "')";
            StrUser[1] = "INSERT INTO USER_DETAILS VALUES(" + User[0] + ",'" + User[1] + "','" + User[2] + "'," + User[3] + ",'" + User[4] + "','" + User[5] + "','" + User[6] + "'," + User[7] + ",'" + User[8] + "','" + User[9] + "')";
            StrUser[2] = "INSERT INTO USER_ACCOUNTS VALUES(" + Acc[0] + ",'" + Acc[1] + "','" + Acc[2] + "'," + Acc[3] + ",'" + Acc[4] + "'," + Acc[5] + "," + Acc[6] + ")";
            StrUser[3] = "UPDATE SEQUENCE_ID SET SEQ_USER_ID=SEQ_USER_ID+1";
            if (Obj.Fn_Execute_Query(Conn, StrUser) == true)
            {
                Pr_Clear_Fields();
                Obj.Pr_ASPNET_MessageBox("User Details Saved Successfully");
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox( MdlCommon. MsgStr);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    private void Pr_Login_Details(string[] Login)
    {
        Login[0] = Obj.Fn_Sequence_Table("SEQ_USER_ID", Conn);
        Login[1] = Strings.Trim(Txt_UserName.Text);
        Login[2] = Strings.Trim(Txt_Password.Text);
    }

    private void Pr_Fill_User_Details(string[] User)
    {
        User[0] = Obj.Fn_Sequence_Table("SEQ_USER_ID", Conn);
        User[1] = Strings.Trim(Strings.UCase(Txt_FullName.Text));
        User[2] = Strings.Trim(Strings.UCase(Txt_LastName.Text));
        User[3] = Strings.Trim(Txt_Age.Text);
        User[4] = Strings.Replace(Strings.Trim(Strings.UCase(Txt_Address.Text)), "'", "''");
        User[5] = Strings.Trim(Strings.UCase(Drp_Gender.SelectedItem.Text));
        User[6] = Drp_Day.SelectedItem.Text + "/" + Strings.Trim(Strings.UCase(Drp_Month.SelectedItem.Value)) + "/" + Drp_Year.SelectedItem.Text;
        User[7] = Strings.Trim(Txt_MobNo.Text);
        User[8] = Strings.Trim(Strings.UCase(Drp_Service.SelectedItem.Text));
        User[9] = Strings.Trim(Txt_Email.Text);
    }

    private void Pr_Acc_Details(string[] Acc)
    {
        Acc[0] = Obj.Fn_Sequence_Table("SEQ_USER_ID", Conn);
        Acc[1] = Strings.Trim(Strings.UCase(Txt_FullName.Text));
        Acc[2] = Strings.Trim(Strings.UCase(Drp_Banks.SelectedItem.Text));
        Acc[3] = Strings.Trim(Txt_Acc_No.Text);
        if (!string.IsNullOrEmpty(Txt_Crd1.Text) | !string.IsNullOrEmpty(Txt_Crd2.Text) | !string.IsNullOrEmpty(Txt_Crd3.Text) | !string.IsNullOrEmpty(Txt_Crd4.Text))
        {
            Acc[4] = Txt_Crd1.Text + "-" + Txt_Crd2.Text + "-" + Txt_Crd3.Text + "-" + Txt_Crd4.Text;
        }
        else
        {
            Acc[4] = "NO CARD";
        }
        Acc[5] = Strings.Trim(Strings.UCase(Txt_PinNo.Text));
        Acc[6] = Strings.Trim(Txt_Balance.Text);
    }

  

    private bool Fn_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_FullName.Text) | Obj.Fn_Check_Characters(Txt_FullName) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Full Name");
            return functionReturnValue;
        }
        if (!string.IsNullOrEmpty(Txt_LastName.Text))
        {
            if (Obj.Fn_Check_Characters(Txt_LastName) == false)
            {
                functionReturnValue = true;
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Last Name");
                return functionReturnValue;
            }
        }
        if (string.IsNullOrEmpty(Txt_Age.Text) | Obj.Fn_Check_Numbers(Txt_Age) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Age");
            return functionReturnValue;
        }
        if (Drp_Gender.SelectedItem.Text == "Select")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Select Gender");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Address.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Address");
            return functionReturnValue;
        }
        if (Drp_Day.SelectedItem.Text == "Day")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please select a valid DOB");
            return functionReturnValue;
        }
        if (Drp_Month.SelectedItem.Text == "Month")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please select a valid DOB");
            return functionReturnValue;
        }
        if (Drp_Year.SelectedItem.Text == "Year")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please select a valid DOB");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_MobNo.Text) | Obj.Fn_Check_Numbers(Txt_MobNo) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Mobile No");
            return functionReturnValue;
        }
        if (Drp_Service.SelectedItem.Text == "Select")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please select a valid Service Name");
            return functionReturnValue;
        }
        if (Drp_Banks.SelectedItem.Text == "Select")
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please select a valid Bank Name");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Acc_No.Text) | Obj.Fn_Check_Numbers(Txt_Acc_No) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Account No");
            return functionReturnValue;
        }
        if (!string.IsNullOrEmpty(Txt_Crd1.Text) | !string.IsNullOrEmpty(Txt_Crd2.Text) | !string.IsNullOrEmpty(Txt_Crd3.Text) | !string.IsNullOrEmpty(Txt_Crd4.Text))
        {
            if (Obj.Fn_Check_Numbers(Txt_Crd1) == false | Obj.Fn_Check_Numbers(Txt_Crd2) == false | Obj.Fn_Check_Numbers(Txt_Crd3) == false | Obj.Fn_Check_Numbers(Txt_Crd4) == false)
            {
                functionReturnValue = true;
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card Number");
                return functionReturnValue;
            }
            if (Strings.Len(Txt_Crd1.Text) < 4 | Strings.Len(Txt_Crd1.Text) < 4 | Strings.Len(Txt_Crd1.Text) < 4 | Strings.Len(Txt_Crd1.Text) < 4)
            {
                functionReturnValue = true;
                Obj.Pr_ASPNET_MessageBox("Please enter a valid Credit Card No");
                return functionReturnValue;
            }
        }
        if (string.IsNullOrEmpty(Txt_PinNo.Text) | Obj.Fn_Check_Numbers(Txt_PinNo) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Pin Number");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Balance.Text) | Obj.Fn_Check_Numbers(Txt_Balance) == false)
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Please enter a valid Balance Amount");
            return functionReturnValue;
        }
        return functionReturnValue;
    }

    private bool Fn_Login_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_UserName.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Click - Get UserName Button");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Password.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Password");
            return functionReturnValue;
        }
        return functionReturnValue;
    }

    private void Pr_Clear_Fields()
    {
        Txt_FullName.Text = "";
        Txt_LastName.Text = "";
        Txt_Address.Text = "";
        Drp_Gender.ClearSelection();
        Txt_Age.Text = "";
        Txt_MobNo.Text = "";
        Txt_Email.Text = "";
        Drp_Service.ClearSelection();
        Drp_Banks.ClearSelection();
        Drp_Day.ClearSelection();
        Drp_Month.ClearSelection();
        Drp_Year.ClearSelection();
        Txt_Acc_No.Text = "";
        Txt_Crd1.Text = "";
        Txt_Crd2.Text = "";
        Txt_Crd3.Text = "";
        Txt_Crd4.Text = "";
        Txt_UserName.Text = "";
        Txt_Password.Text = "";
        Txt_PinNo.Text = "";
        Txt_Balance.Text = "";
    }



    protected void Btn_Clear_Click(object sender, EventArgs e)
    {
        Pr_Clear_Fields();
    }

    protected void Txt_Crd2_TextChanged(object sender, EventArgs e)
    {

    }
}