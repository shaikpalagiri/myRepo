﻿using System.Linq;
using System.Web;
using System.Data.SqlClient;
/// <summary>
/// Summary description for ClsDb
/// </summary>
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Web.UI.WebControls;
public class ClsDb
{

	SqlConnection Conn = new SqlConnection();
	public string Fn_Build_Insert_String(string TableName, string[] ValArray, ref string[,] MetaArray)
	{
		string functionReturnValue = null;
		string Str = null;
		try {
			functionReturnValue = "";
			Str = "INSERT INTO " + TableName + " (";
			for (int i = Information.LBound(MetaArray); i <= Information.UBound(MetaArray); i++) {
				if (string.IsNullOrEmpty(Strings.Trim(ValArray[i]))) {
					if (MetaArray[i, 2] == "0") {
						functionReturnValue = "";
					}
				} else {
					Str = Str + MetaArray[i, 0] + ",";
				}
			}
			Str = Strings.Mid(Str, 1, Strings.Len(Str) - 1);
			Str = Str + ")VALUES(";

			for (int i = Information.LBound(ValArray); i <= Information.UBound(ValArray); i++) {
				if (!string.IsNullOrEmpty(Strings.Trim(ValArray[i]))) {
					Str = Str + Fn_Check_DataType(MetaArray[i, 1].ToString(), ValArray[i].ToString());
					Str = Str + ",";
				}
			}
			Str = Strings.Mid(Str, 1, Strings.Len(Str) - 1);
			Str = Str + ")";
		} catch {
			functionReturnValue = "";
		}
		functionReturnValue = Str;
		return functionReturnValue;
	}

	public string Fn_Check_DataType(string DataType, string ValStr)
	{
		switch (DataType) {
			case "108":
				break;
			default:
				ValStr = "'" + ValStr + "'";
				break;
		}
		return ValStr;
	}

	public bool Fn_Execute_Query(SqlConnection Conn, string[] SqlArray, bool CommitOpt = true, SqlTransaction DbTransaction = null)
	{

		bool BlnOk = false;
		int i = 0;
		SqlCommand Cmd = new SqlCommand();
		SqlTransaction Trans = default(SqlTransaction);
		try {
			BlnOk = true;
			if (CommitOpt) {
				Trans = Conn.BeginTransaction();
				Cmd.Connection = Conn;
				Cmd.Transaction = Trans;
			} else {
				Cmd.Connection = Conn;
				Cmd.Transaction = Trans;
			}

			for (i = Information.LBound(SqlArray); i <= Information.UBound(SqlArray); i++) {
				if (string.IsNullOrEmpty(Strings.Trim(SqlArray[i])) | Strings.Len(SqlArray[i]) == 0) {
					BlnOk = false;
					break; // TODO: might not be correct. Was : Exit For
				}
				Cmd.CommandText = SqlArray[i];
				Cmd.ExecuteNonQuery();
			}

		} catch (Exception Er) {
            MdlCommon.MsgStr = Er.Message;
			BlnOk = false;
			goto Exec;
		}
		Exec:
		if (CommitOpt & BlnOk) {
			Trans.Commit();
		} else if (CommitOpt & (!BlnOk)) {
			Trans.Rollback();
		}
		return BlnOk;
	}

	public void Pr_ASPNET_MessageBox(string Message)
	{
		System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE = \"JavaScript\">" + Constants.vbCrLf);
		System.Web.HttpContext.Current.Response.Write("alert(\"" + Message + "\")" + Constants.vbCrLf);
		System.Web.HttpContext.Current.Response.Write("</SCRIPT>");
	}

	public void Pr_Fill_Combo_Months_Alpha(DropDownList E)
	{
        System.DateTime Dt;
		int i = 0;
		Dt = Convert.ToDateTime("1/1/2004");
		E.Items.Clear();
		ListItem MonthItem = new ListItem();
		MonthItem.Text = "Month";
		MonthItem.Value = "Month";
		E.Items.Add(MonthItem);
		for (i = 1; i <= 12; i++) {
			ListItem Item = new ListItem();
			Item.Text = Strings.Format(Dt, "MMM");
			Item.Value = i.ToString();
			E.Items.Add(Item);
			Dt = DateAndTime.DateAdd(DateInterval.Month, 1, Dt);
		}
	}

	public void Pr_Fill_Combo_Years(DropDownList E)
	{
		E.Items.Clear();
		ListItem YearItem = new ListItem();
		YearItem.Text = "Year";
		YearItem.Value = "Year";
		E.Items.Add(YearItem);
		for (int i = 1987; i >= 1950; i += -1) {
			ListItem NewItem = new ListItem();
			NewItem.Text = i.ToString();
			NewItem.Value = i.ToString();
			E.Items.Add(NewItem);
		}
	}

	public void Pr_Fill_Combo_Selected_Years( ref DropDownList E, int FromYear, int ToYear,  int Stepping = 1, string DefaultText = "Year")
	{
		
		E.Items.Clear();
		ListItem YearItem = new ListItem();
		YearItem.Text = DefaultText;
		YearItem.Value = DefaultText;
		E.Items.Add(YearItem);
		for (int i = FromYear; i <= ToYear; i += Stepping) {
			ListItem NewItem = new ListItem();
			NewItem.Text = i.ToString();
			NewItem.Value = i.ToString();
			E.Items.Add(NewItem);
		}
	}

	public void Pr_Bind_Grid(SqlConnection Conn, string Str, GridView  G)
	{
		SqlDataAdapter Dap = new SqlDataAdapter(Str, Conn);
		DataSet Ds = new DataSet();
		Dap.Fill(Ds);
		G.DataSource = Ds;
		G.DataBind();
	}

	public string  Fn_Sequence_Table(string ColumnName, SqlConnection Conn, string TableName = "")
	{
		long functionReturnValue = 0;
		DataSet Ds = new DataSet();
		string Str = null;
		if (string.IsNullOrEmpty(TableName)) {
			Str = "SELECT " + ColumnName + " FROM SEQUENCE_ID";
		} else {
			Str = "SELECT " + ColumnName + " FROM " + TableName + "";
		}
       	SqlDataAdapter Da = new SqlDataAdapter(Str, Conn);
		Da.Fill(Ds);
		if (Ds.Tables[0].Rows.Count > 0) {
            long.TryParse(Ds.Tables[0].Rows[0][0].ToString(), out functionReturnValue);
        
        } 
        else {
			functionReturnValue = -1;
		}
		return functionReturnValue.ToString();
	}

	public bool Fn_Check_Characters(TextBox T)
	{
		bool functionReturnValue = false;
		string Str = null;
		string j = null;
		int i = 0;
		Str = T.Text;
		for (i = 1; i <= Strings.Len(Str); i++) {
			j = Strings.Mid(Str, i, 1);
			if ((Strings.Asc(j) >= 65 & Strings.Asc(j) <= 90) | (Strings.Asc(j) >= 97 & Strings.Asc(j) <= 122) | (Strings.Asc(j) == 32)) {
				functionReturnValue = true;
			} else {
				functionReturnValue = false;
				break; // TODO: might not be correct. Was : Exit For
			}
		}
		return functionReturnValue;
	}
    /// <summary>
    /// To validate the textbox is containing numerics or not
    /// </summary>
    /// <param name="T"></param>
    /// <returns></returns>
	public bool Fn_Check_Numbers(TextBox T)
    {
        #region declaring variables

        bool functionReturnValue = false;
		string Str = null;
		string j = null;
		int i = 0;
        #endregion
        Str = T.Text;

		for (i = 1; i <= Strings.Len(Str); i++) {
			j = Strings.Mid(Str, i, 1);
			if ((Strings.Asc(j) >= 48 & Strings.Asc(j) <= 57) | (Strings.Asc(j) == 46)) {
				functionReturnValue = true;
			} else {
				functionReturnValue = false;
				break; // TODO: might not be correct. Was : Exit For
			}
		}
		return functionReturnValue;
	}

	public void Pr_Month_Validations(DropDownList EDay, DropDownList Emonth, DropDownList EYear)
	{
		string Str = null;
		if (EYear.SelectedItem.Text == "Year" | Emonth.SelectedItem.Text == "Month") {
			return;
		}
		if (Emonth.SelectedItem.Text == "Feb")
        {
  
			if ((int.Parse(EYear.SelectedItem.Text.ToString()) % 4) == 0)
            {
				Pr_Fill_Combo_Days(EDay, 29);
			} 
            else {
				Pr_Fill_Combo_Days(EDay, 28);
			}
		} else {
			Str = Emonth.SelectedItem.Text;
			if (Str == "Jan" | Str == "Mar" | Str == "May" | Str == "Jul" | Str == "Aug" | Str == "Oct" | Str == "Dec") {
				Pr_Fill_Combo_Days(EDay, 31);
			} else {
				Pr_Fill_Combo_Days(EDay, 30);
			}
		}
	}

	private void Pr_Fill_Combo_Days(DropDownList E, int Days)
	{
		int i = 0;
		E.Items.Clear();
		ListItem DayItem = new ListItem();
		DayItem.Text = "Day";
		DayItem.Value = "Day";
		E.Items.Add(DayItem);
		for (i = 1; i <= Days; i++) {
			ListItem NewItem = new ListItem();
			NewItem.Text = i.ToString();
			NewItem.Value = i.ToString();
			E.Items.Add(NewItem);
		}
	}

	public bool Fn_Check_Mob_Number(SqlConnection Conn, string Str, TextBox T)
	{
		bool functionReturnValue = false;
		string Mob = Strings.Mid(T.Text, 1, 5);
		int Cnt = 0;
		SqlCommand Cmd = new SqlCommand(Str, Conn);
		SqlDataReader Dr = default(SqlDataReader);
        
        Dr = Cmd.ExecuteReader();
		functionReturnValue = false;
		while (Dr.Read()) {
			if (Mob != Dr[0]) {
				functionReturnValue = false;
			} else {
				functionReturnValue = true;
				break; // TODO: might not be correct. Was : Exit Do
			}
		}
		Dr.Close();
		return functionReturnValue;
	}

}

