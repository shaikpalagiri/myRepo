﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for MdlCommon
/// </summary>
public static class MdlCommon
{
    public static string MsgStr = String.Empty;
    public static SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EcellConnectionString"].ToString());

    public static SqlConnection DBConnect()
    {
      if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
      con.Open();
      return con;
    }



}