﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
public class ClsMob
{
    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();
    string[,] USER_LOGIN_MetaArray = new string[3, 3];
    string[,] USER_DETAILS_MetaArray = new string[10, 3];
    string[,] USER_ACC_MetaArray = new string[7, 3];
    string[,] SERVICE_MetaArray = new string[2, 3];
    string[,] POST_PROVIDERS_MetaArray = new string[2, 3];
    string[,] RECHARGE_MetaArray = new string[13, 3];
    string[,] SERVICE_PLAN_MetaArray = new string[5, 3];
    string[,] POST_PAID_MetaArray = new string[6, 3];
    string[,] POST_PAID_BOOK_MetaArray = new string[10, 3];
    string[,] MOB_SHOP_MetaArray = new string[6, 3];

    string[,] MOB_BOOK_MetaArray = new string[12, 3];
    private void Pr_USER_LOGIN_PopArray()
    {
        USER_LOGIN_MetaArray[0, 0] = "USER_LOG_ID";
        USER_LOGIN_MetaArray[0, 1] = "108";
        USER_LOGIN_MetaArray[0, 2] = "0";
        USER_LOGIN_MetaArray[1, 0] = "USER_LOG_NAME";
        USER_LOGIN_MetaArray[1, 1] = "167";
        USER_LOGIN_MetaArray[1, 2] = "0";
        USER_LOGIN_MetaArray[2, 0] = "USER_PASSWORD";
        USER_LOGIN_MetaArray[2, 1] = "167";
        USER_LOGIN_MetaArray[2, 2] = "0";
    }

    private void Pr_USER_DETAILS_PopArray()
    {
        USER_DETAILS_MetaArray[0, 0] = "USER_DET_ID";
        USER_DETAILS_MetaArray[0, 1] = "108";
        USER_DETAILS_MetaArray[0, 2] = "0";
        USER_DETAILS_MetaArray[1, 0] = "FULL_NAME";
        USER_DETAILS_MetaArray[1, 1] = "167";
        USER_DETAILS_MetaArray[1, 2] = "0";
        USER_DETAILS_MetaArray[2, 0] = "LAST_NAME";
        USER_DETAILS_MetaArray[2, 1] = "167";
        USER_DETAILS_MetaArray[2, 2] = "1";
        USER_DETAILS_MetaArray[3, 0] = "AGE";
        USER_DETAILS_MetaArray[3, 1] = "108";
        USER_DETAILS_MetaArray[3, 2] = "0";
        USER_DETAILS_MetaArray[4, 0] = "ADDRESS";
        USER_DETAILS_MetaArray[4, 1] = "167";
        USER_DETAILS_MetaArray[4, 2] = "0";
        USER_DETAILS_MetaArray[5, 0] = "GENDER";
        USER_DETAILS_MetaArray[5, 1] = "167";
        USER_DETAILS_MetaArray[5, 2] = "0";
        USER_DETAILS_MetaArray[6, 0] = "DOB";
        USER_DETAILS_MetaArray[6, 1] = "167";
        USER_DETAILS_MetaArray[6, 2] = "0";
        USER_DETAILS_MetaArray[7, 0] = "MOBILE_NO";
        USER_DETAILS_MetaArray[7, 1] = "108";
        USER_DETAILS_MetaArray[7, 2] = "0";
        USER_DETAILS_MetaArray[8, 0] = "SERVICE_NAME";
        USER_DETAILS_MetaArray[8, 1] = "167";
        USER_DETAILS_MetaArray[8, 2] = "0";
        USER_DETAILS_MetaArray[9, 0] = "EMAIL_ID";
        USER_DETAILS_MetaArray[9, 1] = "167";
        USER_DETAILS_MetaArray[9, 2] = "1";
    }

    private void Pr_USER_ACC_PopArray()
    {
        USER_ACC_MetaArray[0, 0] = "USER_ACC_ID";
        USER_ACC_MetaArray[0, 1] = "108";
        USER_ACC_MetaArray[0, 2] = "0";
        USER_ACC_MetaArray[1, 0] = "USERNAME";
        USER_ACC_MetaArray[1, 1] = "167";
        USER_ACC_MetaArray[1, 2] = "0";
        USER_ACC_MetaArray[2, 0] = "BANK_NAME";
        USER_ACC_MetaArray[2, 1] = "167";
        USER_ACC_MetaArray[2, 2] = "0";
        USER_ACC_MetaArray[3, 0] = "ACC_NO";
        USER_ACC_MetaArray[3, 1] = "108";
        USER_ACC_MetaArray[3, 2] = "0";
        USER_ACC_MetaArray[4, 0] = "CREDIT_CARD_NO";
        USER_ACC_MetaArray[4, 1] = "167";
        USER_ACC_MetaArray[4, 2] = "1";
        USER_ACC_MetaArray[5, 0] = "PIN_NUMBER";
        USER_ACC_MetaArray[5, 1] = "108";
        USER_ACC_MetaArray[5, 2] = "0";
        USER_ACC_MetaArray[6, 0] = "AVAIL_BAL";
        USER_ACC_MetaArray[6, 1] = "108";
        USER_ACC_MetaArray[6, 2] = "0";
    }


    private void Pr_SERVICE_PopArray()
    {
        SERVICE_MetaArray[0, 0] = "PROVIDER_ID";
        SERVICE_MetaArray[0, 1] = "108";
        SERVICE_MetaArray[0, 2] = "0";
        SERVICE_MetaArray[1, 0] = "PROVIDER_NAME";
        SERVICE_MetaArray[1, 1] = "167";
        SERVICE_MetaArray[1, 2] = "0";
    }

    private void Pr_POST_PROVIDERS_PopArray()
    {
        POST_PROVIDERS_MetaArray[0, 0] = "PROVIDER_ID";
        POST_PROVIDERS_MetaArray[0, 1] = "108";
        POST_PROVIDERS_MetaArray[0, 2] = "0";
        POST_PROVIDERS_MetaArray[1, 0] = "PROVIDER_NAME";
        POST_PROVIDERS_MetaArray[1, 1] = "167";
        POST_PROVIDERS_MetaArray[1, 2] = "0";
    }

    private void Pr_SERVICE_PLAN_PopArray()
    {
        SERVICE_PLAN_MetaArray[0, 0] = "SER_PLAN_ID";
        SERVICE_PLAN_MetaArray[0, 1] = "108";
        SERVICE_PLAN_MetaArray[0, 2] = "0";
        SERVICE_PLAN_MetaArray[1, 0] = "PLAN_NAME";
        SERVICE_PLAN_MetaArray[1, 1] = "167";
        SERVICE_PLAN_MetaArray[1, 2] = "0";
        SERVICE_PLAN_MetaArray[2, 0] = "CARD_COST";
        SERVICE_PLAN_MetaArray[2, 1] = "108";
        SERVICE_PLAN_MetaArray[2, 2] = "0";
        SERVICE_PLAN_MetaArray[3, 0] = "TALK_VALUE";
        SERVICE_PLAN_MetaArray[3, 1] = "108";
        SERVICE_PLAN_MetaArray[3, 2] = "0";
        SERVICE_PLAN_MetaArray[4, 0] = "VALIDITY_PERIOD";
        SERVICE_PLAN_MetaArray[4, 1] = "167";
        SERVICE_PLAN_MetaArray[4, 2] = "0";
    }

    private void Pr_USER_RECHARGE_PopArray()
    {
        RECHARGE_MetaArray[0, 0] = "RCHG_ID";
        RECHARGE_MetaArray[0, 1] = "108";
        RECHARGE_MetaArray[0, 2] = "0";
        RECHARGE_MetaArray[1, 0] = "USER_RCHG_ID";
        RECHARGE_MetaArray[1, 1] = "108";
        RECHARGE_MetaArray[1, 2] = "0";
        RECHARGE_MetaArray[2, 0] = "USERNAME";
        RECHARGE_MetaArray[2, 1] = "167";
        RECHARGE_MetaArray[2, 2] = "0";
        RECHARGE_MetaArray[3, 0] = "USER_MOB_NO";
        RECHARGE_MetaArray[3, 1] = "108";
        RECHARGE_MetaArray[3, 2] = "0";
        RECHARGE_MetaArray[4, 0] = "USER_ACC_CARD_NO";
        RECHARGE_MetaArray[4, 1] = "167";
        RECHARGE_MetaArray[4, 2] = "0";
        RECHARGE_MetaArray[5, 0] = "RCHG_FOR";
        RECHARGE_MetaArray[5, 1] = "167";
        RECHARGE_MetaArray[5, 2] = "0";
        RECHARGE_MetaArray[6, 0] = "FRND_MOB_NO";
        RECHARGE_MetaArray[6, 1] = "167";
        RECHARGE_MetaArray[6, 2] = "1";
        RECHARGE_MetaArray[7, 0] = "RCHG_CARD_NAME";
        RECHARGE_MetaArray[7, 1] = "167";
        RECHARGE_MetaArray[7, 2] = "0";
        RECHARGE_MetaArray[8, 0] = "PLAN_NAME";
        RECHARGE_MetaArray[8, 1] = "167";
        RECHARGE_MetaArray[8, 2] = "0";
        RECHARGE_MetaArray[9, 0] = "DATE_OF_REG";
        RECHARGE_MetaArray[9, 1] = "61";
        RECHARGE_MetaArray[9, 2] = "0";
        RECHARGE_MetaArray[10, 0] = "CARD_COST";
        RECHARGE_MetaArray[10, 1] = "108";
        RECHARGE_MetaArray[10, 2] = "1";
        RECHARGE_MetaArray[11, 0] = "STATUS";
        RECHARGE_MetaArray[11, 1] = "167";
        RECHARGE_MetaArray[11, 2] = "0";
        RECHARGE_MetaArray[12, 0] = "DATE_OF_RCHG";
        RECHARGE_MetaArray[12, 1] = "61";
        RECHARGE_MetaArray[12, 2] = "1";
    }

    private void Pr_POST_PAID_PopArray()
    {
        POST_PAID_MetaArray[0, 0] = "PROVIDER_ID";
        POST_PAID_MetaArray[0, 1] = "108";
        POST_PAID_MetaArray[0, 2] = "0";
        POST_PAID_MetaArray[1, 0] = "PLAN_NAME";
        POST_PAID_MetaArray[1, 1] = "167";
        POST_PAID_MetaArray[1, 2] = "0";
        POST_PAID_MetaArray[2, 0] = "PLAN_VALUE";
        POST_PAID_MetaArray[2, 1] = "108";
        POST_PAID_MetaArray[2, 2] = "0";
        POST_PAID_MetaArray[3, 0] = "OUTGOING_RATE";
        POST_PAID_MetaArray[3, 1] = "167";
        POST_PAID_MetaArray[3, 2] = "0";
        POST_PAID_MetaArray[4, 0] = "INCOMING_RATE";
        POST_PAID_MetaArray[4, 1] = "167";
        POST_PAID_MetaArray[4, 2] = "0";
        POST_PAID_MetaArray[5, 0] = "SMS_RATE";
        POST_PAID_MetaArray[5, 1] = "167";
        POST_PAID_MetaArray[5, 2] = "0";
    }

    private void Pr_POST_PAID_BOOK_PopArray()
    {
        POST_PAID_BOOK_MetaArray[0, 0] = "USERNAME";
        POST_PAID_BOOK_MetaArray[0, 1] = "167";
        POST_PAID_BOOK_MetaArray[0, 2] = "0";
        POST_PAID_BOOK_MetaArray[1, 0] = "ADDRESS";
        POST_PAID_BOOK_MetaArray[1, 1] = "167";
        POST_PAID_BOOK_MetaArray[1, 2] = "0";
        POST_PAID_BOOK_MetaArray[2, 0] = "CONTACT_NO";
        POST_PAID_BOOK_MetaArray[2, 1] = "167";
        POST_PAID_BOOK_MetaArray[2, 2] = "0";
        POST_PAID_BOOK_MetaArray[3, 0] = "AGE";
        POST_PAID_BOOK_MetaArray[3, 1] = "108";
        POST_PAID_BOOK_MetaArray[3, 2] = "0";
        POST_PAID_BOOK_MetaArray[4, 0] = "GENDER";
        POST_PAID_BOOK_MetaArray[4, 1] = "167";
        POST_PAID_BOOK_MetaArray[4, 2] = "0";
        POST_PAID_BOOK_MetaArray[5, 0] = "SERVICE_NAME";
        POST_PAID_BOOK_MetaArray[5, 1] = "167";
        POST_PAID_BOOK_MetaArray[5, 2] = "0";
        POST_PAID_BOOK_MetaArray[6, 0] = "POST_PAID_BOOKED_NUM";
        POST_PAID_BOOK_MetaArray[6, 1] = "167";
        POST_PAID_BOOK_MetaArray[6, 2] = "0";
        POST_PAID_BOOK_MetaArray[7, 0] = "PLAN_NAME";
        POST_PAID_BOOK_MetaArray[7, 1] = "167";
        POST_PAID_BOOK_MetaArray[7, 2] = "0";
        POST_PAID_BOOK_MetaArray[8, 0] = "DATE_OF_BOOK";
        POST_PAID_BOOK_MetaArray[8, 1] = "167";
        POST_PAID_BOOK_MetaArray[8, 2] = "0";
        POST_PAID_BOOK_MetaArray[9, 0] = "STATUS";
        POST_PAID_BOOK_MetaArray[9, 1] = "167";
        POST_PAID_BOOK_MetaArray[9, 2] = "0";
    }

    private void Pr_MOB_SHOP_PopArray()
    {
        MOB_SHOP_MetaArray[0, 0] = "MOB_ID";
        MOB_SHOP_MetaArray[0, 1] = "108";
        MOB_SHOP_MetaArray[0, 2] = "0";
        MOB_SHOP_MetaArray[1, 0] = "MOB_MAKE";
        MOB_SHOP_MetaArray[1, 1] = "167";
        MOB_SHOP_MetaArray[1, 2] = "0";
        MOB_SHOP_MetaArray[2, 0] = "MOB_MODEL";
        MOB_SHOP_MetaArray[2, 1] = "167";
        MOB_SHOP_MetaArray[2, 2] = "0";
        MOB_SHOP_MetaArray[3, 0] = "MOB_COST";
        MOB_SHOP_MetaArray[3, 1] = "108";
        MOB_SHOP_MetaArray[3, 2] = "0";
        MOB_SHOP_MetaArray[4, 0] = "FEATURES";
        MOB_SHOP_MetaArray[4, 1] = "167";
        MOB_SHOP_MetaArray[4, 2] = "0";
        MOB_SHOP_MetaArray[5, 0] = "MOB_PIC";
        MOB_SHOP_MetaArray[5, 1] = "167";
        MOB_SHOP_MetaArray[5, 2] = "0";
    }

    private void Pr_MOB_BOOK_PopArray()
    {
        MOB_BOOK_MetaArray[0, 0] = "BOOKING_ID";
        MOB_BOOK_MetaArray[0, 1] = "108";
        MOB_BOOK_MetaArray[0, 2] = "0";
        MOB_BOOK_MetaArray[1, 0] = "USERNAME";
        MOB_BOOK_MetaArray[1, 1] = "167";
        MOB_BOOK_MetaArray[1, 2] = "0";
        MOB_BOOK_MetaArray[2, 0] = "ADDRESS";
        MOB_BOOK_MetaArray[2, 1] = "167";
        MOB_BOOK_MetaArray[2, 2] = "0";
        MOB_BOOK_MetaArray[3, 0] = "AGE";
        MOB_BOOK_MetaArray[3, 1] = "108";
        MOB_BOOK_MetaArray[3, 2] = "0";
        MOB_BOOK_MetaArray[4, 0] = "GENDER";
        MOB_BOOK_MetaArray[4, 1] = "167";
        MOB_BOOK_MetaArray[4, 2] = "0";
        MOB_BOOK_MetaArray[5, 0] = "CONTACT_NO";
        MOB_BOOK_MetaArray[5, 1] = "167";
        MOB_BOOK_MetaArray[5, 2] = "0";
        MOB_BOOK_MetaArray[6, 0] = "EMAIL";
        MOB_BOOK_MetaArray[6, 1] = "167";
        MOB_BOOK_MetaArray[6, 2] = "0";
        MOB_BOOK_MetaArray[7, 0] = "MOB_MAKE";
        MOB_BOOK_MetaArray[7, 1] = "167";
        MOB_BOOK_MetaArray[7, 2] = "0";
        MOB_BOOK_MetaArray[8, 0] = "MOB_MODEL";
        MOB_BOOK_MetaArray[8, 1] = "167";
        MOB_BOOK_MetaArray[8, 2] = "0";
        MOB_BOOK_MetaArray[9, 0] = "MOB_COST";
        MOB_BOOK_MetaArray[9, 1] = "108";
        MOB_BOOK_MetaArray[9, 2] = "0";
        MOB_BOOK_MetaArray[10, 0] = "DATE_OF_BOOK";
        MOB_BOOK_MetaArray[10, 1] = "167";
        MOB_BOOK_MetaArray[10, 2] = "0";
        MOB_BOOK_MetaArray[11, 0] = "STATUS";
        MOB_BOOK_MetaArray[11, 1] = "167";
        MOB_BOOK_MetaArray[11, 2] = "0";
    }

    public bool Fn_Save_Login(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrLog = new string[1];
        Pr_USER_LOGIN_PopArray();
        StrLog[0] = Obj.Fn_Build_Insert_String("USER_LOGIN", ValArray, ref USER_LOGIN_MetaArray);
        if (Obj.Fn_Execute_Query(Conn, StrLog) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Personal(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrDet = new string[1];
        Pr_USER_DETAILS_PopArray();
        StrDet[0] = Obj.Fn_Build_Insert_String("USER_DETAILS", ValArray,ref USER_DETAILS_MetaArray);
        if (Obj.Fn_Execute_Query(Conn, StrDet) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Account(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrAcc = new string[2];
        Pr_USER_ACC_PopArray();
        StrAcc[0] = Obj.Fn_Build_Insert_String("USER_ACCOUNTS", ValArray, ref USER_ACC_MetaArray);
        StrAcc[1] = "UPDATE SEQUENCE_ID SET SEQ_USER_ID = SEQ_USER_ID + 1";
        if (Obj.Fn_Execute_Query(Conn, StrAcc) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Provider(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrProv = new string[2];
        Pr_SERVICE_PopArray();
        StrProv[0] = Obj.Fn_Build_Insert_String("SERVICE_PROVIDERS", ValArray, ref  SERVICE_MetaArray);
        StrProv[1] = "UPDATE SEQUENCE_ID SET SEQ_PROVIDER_ID = SEQ_PROVIDER_ID + 1";
        if (Obj.Fn_Execute_Query(Conn, StrProv) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Post_Paid_Provider(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] Prov = new string[2];
        Pr_POST_PROVIDERS_PopArray();
        Prov[0] = Obj.Fn_Build_Insert_String("POST_PAID_PROVIDERS", ValArray,ref  POST_PROVIDERS_MetaArray);
        Prov[1] = "UPDATE SEQUENCE_ID SET SEQ_POST_PAID_PROVIDER = SEQ_POST_PAID_PROVIDER + 1";
        if (Obj.Fn_Execute_Query(Conn, Prov) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Service_Plans(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrPlan = new string[1];
        Pr_SERVICE_PLAN_PopArray();
        StrPlan[0] = Obj.Fn_Build_Insert_String("SERVICE_PLANS_DETAILS", ValArray, ref SERVICE_PLAN_MetaArray);
        if (Obj.Fn_Execute_Query(Conn, StrPlan) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_User_Recharge_Details(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrRchg = new string[2];
        Pr_USER_RECHARGE_PopArray();
        StrRchg[0] = Obj.Fn_Build_Insert_String("USER_RECHARGE_DETAILS", ValArray, ref RECHARGE_MetaArray);
        StrRchg[1] = "UPDATE SEQUENCE_ID SET SEQ_RCHG_ID = SEQ_RCHG_ID + 1";
        if (Obj.Fn_Execute_Query(Conn, StrRchg) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Post_Paid_Plans(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrPost = new string[1];
        Pr_POST_PAID_PopArray();
        StrPost[0] = Obj.Fn_Build_Insert_String("POST_PAID_PLANS", ValArray,  ref POST_PAID_MetaArray);
        if (Obj.Fn_Execute_Query(Conn, StrPost) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Post_Paid_Booking(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrPostBook = new string[1];
        Pr_POST_PAID_BOOK_PopArray();
        StrPostBook[0] = Obj.Fn_Build_Insert_String("POST_PAID_BOOKING", ValArray, ref POST_PAID_BOOK_MetaArray);
        if (Obj.Fn_Execute_Query(Conn, StrPostBook) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public bool Fn_Save_Mob_Shop(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrShop = new string[2];
        Pr_MOB_SHOP_PopArray();
        StrShop[0] = Obj.Fn_Build_Insert_String("MOB_SHOP", ValArray, ref MOB_SHOP_MetaArray);
        StrShop[1] = "UPDATE SEQUENCE_ID SET SEQ_MOB_ID = SEQ_MOB_ID + 1";
        if (Obj.Fn_Execute_Query(Conn, StrShop) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }


    public bool Fn_Save_Mob_Phone_Book(SqlConnection Conn, string[] ValArray)
    {
        bool functionReturnValue = false;
        string[] StrMob = new string[2];
        Pr_MOB_BOOK_PopArray();
        StrMob[0] = Obj.Fn_Build_Insert_String("MOB_PHONE_BOOKING", ValArray, ref MOB_BOOK_MetaArray);
        StrMob[1] = "UPDATE SEQUENCE_ID SET SEQ_MOB_BOOK = SEQ_MOB_BOOK + 1";
        if (Obj.Fn_Execute_Query(Conn, StrMob) == true)
        {
            functionReturnValue = true;
        }
        else
        {
            functionReturnValue = false;
        }
        return functionReturnValue;
    }

    public void Pr_Fill_Combo_Providers(SqlConnection Conn, string Str, ref DropDownList E)
    {
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = default(SqlDataReader); 
        Dr = Cmd.ExecuteReader();
        E.Items.Clear();
        ListItem Sel = new ListItem();
        Sel.Text = "Select";
        Sel.Value = "Select";
        E.Items.Add(Sel);
        while (Dr.Read())
        {
            ListItem NewItem = new ListItem();
            NewItem.Text = Dr[1].ToString();
            NewItem.Value = Dr[0].ToString();
            E.Items.Add(NewItem);
        }
        Dr.Close();
    }

    public bool Fn_Check_Credit_Card_No(TextBox T)
    {
        bool functionReturnValue = false;
        string Str = null;
        string j = null;
        int i = 0;
        Str = T.Text;
        for (i = 1; i <= Strings.Len(Str); i++)
        {
            j = Strings.Mid(Str, i, 1);
            if ((Strings.Asc(j) >= 48 & Strings.Asc(j) <= 57) | Strings.Asc(j) == 45)
            {
                functionReturnValue = true;
            }
            else
            {
                functionReturnValue = false;
                break; // TODO: might not be correct. Was : Exit For
            }
        }
        return functionReturnValue;
    }

    public bool Fn_Check_Provider(SqlConnection Conn, string Str, TextBox T)
    {
        bool functionReturnValue = false;
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = default(SqlDataReader);
        Dr = Cmd.ExecuteReader();
        functionReturnValue = true;
        while (Dr.Read())
        {
            if (Strings.Trim(Strings.UCase(T.Text)) == Dr[1].ToString())
            {
                functionReturnValue = false;
                break; // TODO: might not be correct. Was : Exit Do
            }
        }
        Dr.Close();
        return functionReturnValue;
    }

}
