﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Change_Password : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection();

    ClsDb Obj = new ClsDb();
    protected void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
            Conn = MdlCommon.DBConnect();
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }


    protected void Btn_Pwd_Change_Click(object sender, EventArgs e)
    {
        try
        {
            if (Fn_Pwd_Validations() == true)
            {
                return;
            }
            if (Fn_Check_Old_Pwd() == false)
            {
                Obj.Pr_ASPNET_MessageBox("Incorrect Old Password");
                return;
            }
            if (Txt_New_Pwd.Text != Txt_Confirm_Pwd.Text)
            {
                Obj.Pr_ASPNET_MessageBox("Invalid Password Confirmation");
                return;
            }
            string[] StrChng = new string[1];
            StrChng[0] = "UPDATE USER_LOGIN SET USER_PASSWORD = '" + Strings.Trim(Strings.LCase(Txt_New_Pwd.Text)) + "' WHERE USER_LOG_ID = " + Session["USER_ID"] + "";
            if (Obj.Fn_Execute_Query(Conn, StrChng) == true)
            {
                Obj.Pr_ASPNET_MessageBox("Your Password has been Changed Succesfully");
            }
            else
            {
                Obj.Pr_ASPNET_MessageBox (MdlCommon. MsgStr);
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    private bool Fn_Check_Old_Pwd()
    {
        bool functionReturnValue = false;
        string Str = "SELECT USER_PASSWORD FROM USER_LOGIN WHERE USER_LOG_ID = " + Session["USER_ID"] + " AND USER_LOG_NAME = '" + Session["USER_NAME"] + "' AND USER_PASSWORD = '" + Txt_Old_Pwd.Text + "'";
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        functionReturnValue = false;
        while (Dr.Read())
        {
            if (Txt_Old_Pwd.Text == Dr[0].ToString())
            {
                functionReturnValue = true;
                break; // TODO: might not be correct. Was : Exit Do
            }
        }
        Dr.Close();
        return functionReturnValue;
    }



    public bool Fn_Pwd_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_Old_Pwd.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter Old Password");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_New_Pwd.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Enter New Password");
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Confirm_Pwd.Text))
        {
            functionReturnValue = true;
            Obj.Pr_ASPNET_MessageBox("Confirm Your New Password");
            return functionReturnValue;
        }
        return functionReturnValue;
    }
    protected void Btn_Cancel_Click(object sender, EventArgs e)
    {
        Txt_Old_Pwd.Text = "";
        Txt_New_Pwd.Text = "";
        Txt_Confirm_Pwd.Text = "";

    }
    protected void LBtn_View_Plans_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Plans.aspx");
    }
    protected void LBtn_SignOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Index.aspx");
    }
  
    protected void LBtn_BlockMobileNos_Click(object sender, EventArgs e)
    {
        Response.Redirect("BlockMobileNos.aspx");
    }
}