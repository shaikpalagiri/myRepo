﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class BlockMobileNos : System.Web.UI.Page
{

    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mob = new ClsMob();


    private void Page_Load(System.Object sender, System.EventArgs e)
    {
        try
        {
            Response.Expires = 0;
            Response.ExpiresAbsolute = DateAndTime.Now;
            Response.CacheControl = "no-cache";
            Conn = MdlCommon.DBConnect();
            if (!IsPostBack)
            {
                string Str = "SELECT * FROM POST_PAID_PROVIDERS";
                Mob.Pr_Fill_Combo_Providers(Conn, Str, ref Drp_Provider);
                Pr_Get_User_Service_Name();
                Pr_Get_User_BookedMobileNos();
                Pr_Bind_Grid();
                Lbl_Name.Text = "Welcome " + Session["FULL_NAME"].ToString().ToUpper() + "&nbsp;";
                Lbl_Login.Text = "You are logged in as " + Session["USER_NAME"] + "&nbsp;";
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }
    protected void Pr_Bind_Grid()
    {
        string Str = "SELECT * FROM USER_BLOCKMOBILENO_REQUESTS WHERE STATUS in ('Accepted','Rejected','Request') AND username='" + Session["FULL_NAME"] + "'";
        DGrid_Mob_Shop.Visible = true;
        Obj.Pr_Bind_Grid(Conn, Str, DGrid_Mob_Shop);
        if (DGrid_Mob_Shop.Rows.Count == 0)
        {
            DGrid_Mob_Shop.Visible = false;
                  }
    }
    private void Pr_Get_User_BookedMobileNos()
    {
        string mobileprofile = string.Format("SELECT * FROM [POST_PAID_BOOKING] where username='{0}'and (Status='issued' or Status='Blocked')", Session["FULL_NAME"].ToString());
        SqlCommand Cmd = new SqlCommand(mobileprofile, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(Dr);
        Session["MobilesBooked"] = dt;

    
    }
    private void Pr_Get_User_Service_Name()
    {
        int i = int.Parse(Session["USER_ID"].ToString());
        string StrSer = "SELECT B.SERVICE_NAME,B.MOBILE_NO FROM USER_LOGIN A INNER JOIN USER_DETAILS B ON A.USER_LOG_ID=" + i + " AND B.USER_DET_ID=" + i + "";
        SqlCommand Cmd = new SqlCommand(StrSer, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        while (Dr.Read())
        {
            Session["SERVICE"] = Dr[0];
            Session["MOB_NO"] = Dr[1];
        }
        Dr.Close();
    }

    protected void Btn_SendRequest_Click(object sender, EventArgs e)
    {
        string insrequest = String.Format("INSERT INTO [USER_BLOCKMOBILENO_REQUESTS]    ([username]  ,[MobileNo] ,[DoB] ,[DoC],[status],[Reason]) VALUES  ('{0}' ,'{1}','{2}',getdate() ,'Request','{3}')", Session["FULL_NAME"].ToString(), Drp_UserMobileNos.SelectedItem.Text, Lbl_DOB.Text, Txt_Reason.Text);
        Conn = MdlCommon.DBConnect();
        SqlCommand Cmd = new SqlCommand(insrequest, Conn);
        Cmd.ExecuteNonQuery();
        Lbl_Msg.Text = "Request is submitted for Administrator acceptance... please wait";
        Btn_SendRequest.Enabled = false;


    }
    protected void Btn_close_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Plans.aspx");
    }
    protected void LBtn_SignOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Index.aspx");
    }
    protected void LBtn_Change_Pwd_Click(object sender, EventArgs e)
    {

        Response.Redirect("Change_Password.aspx");
    }
    protected void Drp_Provider_SelectedIndexChanged(object sender, EventArgs e)
    {
        Drp_UserMobileNos.Items.Clear();
        DataTable dt = (DataTable)Session["MobilesBooked"];
        string wherecondition=string.Format("service_Name='{0}' ",Drp_Provider.SelectedItem.Text );
        Drp_UserMobileNos.Items.Add("-Select Mobile No-");
        DataRow[] dr=dt.Select(wherecondition);
     foreach(DataRow row in dr)
        {
             Drp_UserMobileNos.Items.Add(new ListItem(row[6].ToString()));
        }

     if (Drp_UserMobileNos.Items.Count == 1)
     {
         Lbl_Msg.Text = "No Mobile No is existing under this service provider";

     }
     else
     {
         Lbl_Msg.Text = string.Empty;
     }
    }
    protected void Drp_BookedMobiles_SelectedIndexChanged(object sender, EventArgs e)
    {
        Lbl_Msg.Text = string.Empty;
        tblMobileBookingDetails.Visible = true;
        DataTable dt = (DataTable)Session["MobilesBooked"];
        string wherecondition = string.Format("service_Name='{0}'  and POST_PAID_BOOKED_NUM='{1}'", Drp_Provider.SelectedItem.Text, Drp_UserMobileNos.SelectedItem.Text);
        DataRow[] dr = dt.Select(wherecondition);
        foreach (DataRow row in dr)
        {
            Lbl_MobileNo.Text = row[6].ToString();
            Lbl_Plan.Text = row[7].ToString();
            Lbl_DOB.Text = row[8].ToString();

        }
        Btn_SendRequest.Enabled = true;

    }
    protected void LBtn_View_Plans_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Plans.aspx");
    }
    protected void DGrid_Mob_Shop_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //PAGENOS CHANGED
    }
    protected void DGrid_Mob_Shop_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        // BLOCKING 

        try
        {
            int i = e.RowIndex;
            string StrDel = string.Format("UPDATE USER_BLOCKMOBILENO_REQUESTS   SET [status] = 'Rejected' ,ConfirmedOn=getdate() WHERE bmid={0}", DGrid_Mob_Shop.Rows[i].Cells[0].Text);
            SqlCommand Cmd = new SqlCommand(StrDel, Conn);
            Cmd.ExecuteNonQuery();
            Obj.Pr_ASPNET_MessageBox("Mobile No Blocking Request is Rejected....");
            Pr_Bind_Grid();

        }
        catch (Exception Er)
        {
        }
    }
    protected void DGrid_Mob_Shop_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = DGrid_Mob_Shop.SelectedIndex;
        string StrAccepted = string.Format("DELETE FROM USER_BLOCKMOBILENO_REQUESTS WHERE bmid={0}", DGrid_Mob_Shop.Rows[i].Cells[0].Text);
        SqlCommand Cmd = new SqlCommand(StrAccepted, Conn);
        Cmd.ExecuteNonQuery();
        string upquery = string.Format("UPDATE [POST_PAID_BOOKING]   SET [STATUS] = 'ISSUED', DATE_OF_BOOK=getdate() WHERE  [USERNAME] = '{0}' and [POST_PAID_BOOKED_NUM] = '{1}'", DGrid_Mob_Shop.Rows[i].Cells[1].Text, DGrid_Mob_Shop.Rows[i].Cells[2].Text);
        Cmd = new SqlCommand(upquery, Conn);
        Cmd.ExecuteNonQuery();

        Obj.Pr_ASPNET_MessageBox("Mobile No is UnBlocked SuccessFully");
        Pr_Bind_Grid();
    }
}