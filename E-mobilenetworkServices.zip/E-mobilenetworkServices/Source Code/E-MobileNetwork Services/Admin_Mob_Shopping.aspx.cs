﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_Mob_Shopping : System.Web.UI.Page
{

    SqlConnection Conn = new SqlConnection();
    ClsDb Obj = new ClsDb();

    ClsMob Mobl = new ClsMob();


    protected void Page_Load(object sender, EventArgs e)
    {
   Conn = MdlCommon.   DBConnect();
        if (!IsPostBack)
        {
            string Str = "SELECT DISTINCT(MOB_MAKE) FROM MOB_SHOP";
            Pr_Fill_Combo(Conn, Str, Drp_Make);
            Img_Preview.Visible = false;
            Table10.Visible = false;
            Table9.Visible = false;
            Btn_Upload.Text = "Upload";
        }
    }

    private void Pr_Fill_Combo(SqlConnection Conn, string Str, DropDownList E)
    {
        SqlCommand Cmd = new SqlCommand(Str, Conn);
        SqlDataReader Dr = null;
        Dr = Cmd.ExecuteReader();
        E.Items.Clear();
        ListItem SelItem = new ListItem();
        SelItem.Text = "Select";
        SelItem.Value = "Select";
        E.Items.Add(SelItem);
        while (Dr.Read())
        {
            ListItem NewItem = new ListItem();
            NewItem.Text = Dr[0].ToString();
            NewItem.Value = Dr[0].ToString();
            E.Items.Add(NewItem);
        }
        Dr.Close();
    }

    private void Pr_Fill_Values(string[] Mob)
    {
        Mob[0] = Obj.Fn_Sequence_Table("SEQ_MOB_ID", Conn);
        Mob[1] = Strings.Trim(Strings.UCase(Txt_Make.Text));
        Mob[2] = Strings.Trim(Strings.UCase(Txt_Model.Text));
        Mob[3] = Strings.Trim(Strings.UCase(Txt_Cost.Text));
        Mob[4] = Strings.Replace(Strings.Trim(Strings.UCase(Txt_Features.Text)), "'", "''");
        if (string.IsNullOrEmpty(File1.Value))
        {
            Mob[5] = "NO PIC";
        }
        else
        {
            Mob[5] = "images\\" + Fn_Upload_File() + "";
        }
    }

    //Function to upload the image file

    private string Fn_Upload_File()
    {
        string functionReturnValue = null;
        if ((File1.PostedFile != null))
        {
            HttpPostedFile postedfile = File1.PostedFile;
            int IND = postedfile.FileName.LastIndexOf ('\\');
            string fname= File1.PostedFile.FileName.Substring(IND,postedfile.FileName.Length-IND  );

            postedfile.SaveAs(Server.MapPath("~/") + "Images/" + fname);
            functionReturnValue = Path.GetFileName(postedfile.FileName);
        }
        return functionReturnValue;
    }

    private void Pr_Clear()
    {
        Drp_Make.ClearSelection();
        Drp_Model.Items.Clear();
        Drp_Model.Items.Add("Select");
        DGrid_Mob.Visible = false;
        Img_Preview.Visible = false;
        Table10.Visible = false;
        Table9.Visible = false;
        Txt_Make.Text = "";
        Txt_Model.Text = "";
        Txt_Cost.Text = "";
        Txt_Features.Text = "";
        //File1.Value = ""
        Btn_Upload.Text = "Upload";
    }

    protected void Drp_Make_SelectedIndexChanged(System.Object sender, System.EventArgs e)
    {
        if (Drp_Make.SelectedItem.Text == "Select")
        {
            Drp_Model.Items.Clear();
            Drp_Model.Items.Add("Select");
            return;
        }
        string Str = "SELECT MOB_MODEL FROM MOB_SHOP WHERE MOB_MAKE = '" + Drp_Make.SelectedItem.Text + "'";
        Pr_Fill_Combo(Conn, Str, Drp_Model);
    }

   
    //Function used to validate the input of each control

    private bool Fn_Validations()
    {
        bool functionReturnValue = false;
        if (string.IsNullOrEmpty(Txt_Make.Text) | Obj.Fn_Check_Characters(Txt_Make) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Mobile Make Name");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Model.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Model No");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Features.Text))
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Features");
            functionReturnValue = true;
            return functionReturnValue;
        }
        if (string.IsNullOrEmpty(Txt_Cost.Text) | Obj.Fn_Check_Numbers(Txt_Cost) == false)
        {
            Obj.Pr_ASPNET_MessageBox("Invalid Mobile Cost");
            functionReturnValue = true;
            return functionReturnValue;
        }
        return functionReturnValue;
    }

    protected void Btn_Upload_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (Fn_Validations() == true)
            {
                return;
            }
            string[] Mob = new string[6];
            Pr_Fill_Values(Mob);
            if (Btn_Upload.Text == "Upload")
            {
                //FileUpload1.SaveAs(Server.MapPath("~/") + "Images/" + FileUpload1.FileName );
                if (Mobl.Fn_Save_Mob_Shop(Conn, Mob) == true)
                {
                    Obj.Pr_ASPNET_MessageBox("Mobile Details Uploaded SuccessFully");
                    string Str = "SELECT DISTINCT(MOB_MAKE) FROM MOB_SHOP";
                    Pr_Fill_Combo(Conn, Str, Drp_Make);
                    Pr_Clear();
                }
                else
                {
                    Obj.Pr_ASPNET_MessageBox("Error, Please Try Again");
                }
            }
            else if (Btn_Upload.Text == "Update Mobile")
            {
                string StrUp = null;
                if (string.IsNullOrEmpty(File1.Value))
                {
                    StrUp = "UPDATE MOB_SHOP SET MOB_MAKE = '" + Mob[1] + "', MOB_MODEL = '" + Mob[2] + "', MOB_COST = " + Mob[3] + ", FEATURES = '" + Mob[4] + "' WHERE MOB_ID = " + Session["ID"] + "";
                }
                else
                {
                    StrUp = "UPDATE MOB_SHOP SET MOB_MAKE = '" + Mob[1] + "', MOB_MODEL = '" + Mob[2] + "', MOB_COST = " + Mob[3] + ", FEATURES = '" + Mob[4] + "', MOB_PIC = '" + Mob[5] + "' WHERE MOB_ID = " + Session["ID"] + "";
                }
                SqlCommand Cmd = new SqlCommand(StrUp, Conn);
                Cmd.ExecuteNonQuery();
                Obj.Pr_ASPNET_MessageBox("Mobile Details Updated SuccessFully");
                Pr_Clear();
                Btn_Upload.Text = "Upload";
            }
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected void Btn_Edit_Delete_Click(System.Object sender, System.EventArgs e)
    {
        try
        {
            if (Drp_Make.SelectedItem.Text == "Select")
            {
                Obj.Pr_ASPNET_MessageBox("Select Mobile Make Name");
                return;
            }
            if (Drp_Model.SelectedItem.Text == "Select")
            {
                Obj.Pr_ASPNET_MessageBox("Select Model Number");
                return;
            }
            string Str = "SELECT * FROM MOB_SHOP WHERE MOB_MAKE = '" + Drp_Make.SelectedItem.Text + "' AND MOB_MODEL = '" + Drp_Model.SelectedItem.Text + "'";
            DGrid_Mob.Visible = true;
            Obj.Pr_Bind_Grid(Conn, Str, DGrid_Mob);
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected void Btn_Cancel_Click(System.Object sender, System.EventArgs e)
    {
        Pr_Clear();
    }

    protected void DGrid_Mob_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
    {

        try
        {
        }
        catch (Exception ex)
        {
            Obj.Pr_ASPNET_MessageBox(ex.Message);
        }
    }






    protected void DGrid_Mob_Plans_SelectedIndexChanged(object sender, EventArgs e)
    {
          try
        {
            int i = DGrid_Mob.SelectedIndex;
            Img_Preview.Visible = true;
            Table10.Visible = true;
            Session["ID"] = DGrid_Mob.Rows[i].Cells[0].Text;
            Txt_Make.Text = DGrid_Mob.Rows[i].Cells[1].Text;
            Txt_Model.Text = DGrid_Mob.Rows[i].Cells[2].Text;
            Txt_Cost.Text = DGrid_Mob.Rows[i].Cells[3].Text;
            Txt_Features.Text = DGrid_Mob.Rows[i].Cells[4].Text;
            if (DGrid_Mob.Rows[i].Cells[5].Text != "NO PIC")
            {
                Table9.Visible = false;
                Table10.Visible = true;
                Img_Preview.ImageUrl = DGrid_Mob.Rows[i].Cells[5].Text;
            }
            else
            {
                Table10.Visible = false;
                Img_Preview.Visible = false;
                Table9.Visible = true;
            }
            Session["IMAGE"] = DGrid_Mob.Rows[i].Cells[5].Text;
         
            Btn_Upload.Text = "Update Mobile";
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected void DGrid_Mob_Plans_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int i = e.RowIndex;
            string StrDel = "DELETE FROM MOB_SHOP WHERE MOB_ID = " + DGrid_Mob.Rows [i].Cells[0].Text + "";
            SqlCommand Cmd = new SqlCommand(StrDel, Conn);
            Cmd.ExecuteNonQuery();
            Obj.Pr_ASPNET_MessageBox("Mobile Model Deleted SuccessFully");
            Drp_Model.Items.Clear();
            DGrid_Mob.Visible = false;
            string Str = "SELECT DISTINCT(MOB_MAKE) FROM MOB_SHOP";
            Pr_Fill_Combo(Conn, Str, Drp_Make);
        }
        catch (Exception Er)
        {
            Obj.Pr_ASPNET_MessageBox(Er.Message);
        }
    }

    protected void DGrid_Mob_Plans_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
}