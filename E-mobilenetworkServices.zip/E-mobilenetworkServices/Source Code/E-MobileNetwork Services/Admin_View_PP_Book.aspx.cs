﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;


public partial class Admin_View_PP_Book : System.Web.UI.Page
{
  
    SqlConnection Conn = new SqlConnection();

		ClsDb Obj = new ClsDb();
		protected void Page_Load(System.Object sender, System.EventArgs e)
		{
		Conn= MdlCommon.DBConnect();
			if (!IsPostBack) {
				Pr_Bind_Users();
				Pr_Bind_Grid();
			}
		}

		protected void Pr_Bind_Users()
		{
			string Str = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING'";
			DGrid_View_Booking.Visible = true;
			Txt_Search_Name.Text = "";
			Lbl_PP.Text = "1";
			Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Booking);
			if (DGrid_View_Booking.Rows .Count == 0) {
				DGrid_View_Booking.Visible = false;
				Txt_Search_Name.Text = "";
			}
		}

		protected void Pr_Bind_Grid()
		{
			string Str = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING'";
			DGrid_Mob_Shop.Visible = true;
			Txt_Mob_Search.Text = "";
			Lbl_Mob.Text = "1";
			Obj.Pr_Bind_Grid(Conn, Str, DGrid_Mob_Shop);
			if (DGrid_Mob_Shop.Rows.Count == 0) {
				DGrid_Mob_Shop.Visible = false;
				Txt_Mob_Search.Text = "";
			}
		}

		protected void Btn_Search_Click(System.Object sender, System.EventArgs e)
		{
			if (string.IsNullOrEmpty(Txt_Search_Name.Text)) {
				Obj.Pr_ASPNET_MessageBox("Enter Name to Search");
				return;
			}
			string Name = Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%";
			string StrName = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
			DGrid_View_Booking.Visible = true;
			Lbl_PP.Text = "2";
			Obj.Pr_Bind_Grid(Conn, StrName, DGrid_View_Booking);
			if (DGrid_View_Booking.Rows.Count == 0) {
				Obj.Pr_ASPNET_MessageBox("No Record matches your Search, Please Try Again");
				DGrid_View_Booking.Visible = false;
			}
		}

		protected void Btn_Mob_Click(System.Object sender, System.EventArgs e)
		{
			if (string.IsNullOrEmpty(Txt_Mob_Search.Text)) {
				Obj.Pr_ASPNET_MessageBox("Enter Name to Search");
				return;
			}
			string Name = Strings.Trim(Strings.UCase(Txt_Mob_Search.Text)) + "%";
			string StrName = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
			DGrid_Mob_Shop.Visible = true;
			Lbl_Mob.Text = "2";
			Obj.Pr_Bind_Grid(Conn, StrName, DGrid_Mob_Shop);
			if (DGrid_Mob_Shop.Rows .Count == 0) {
				Obj.Pr_ASPNET_MessageBox("No Record matches your search, Please try again");
				DGrid_Mob_Shop.Visible = false;
			}
		}

		protected void DGrid_Mob_Shop_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
		}

		
		protected void LBtn_View_PP_Click(System.Object sender, System.EventArgs e)
		{
			Pr_Bind_Users();
		}

		protected void LBtn_View_Mob_Click(System.Object sender, System.EventArgs e)
		{
			Pr_Bind_Grid();
		}

		protected void DGrid_View_Booking_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			try {
				DGrid_View_Booking.PageIndex = e.NewPageIndex;
				string Str = null;
				if (Lbl_PP.Text == "1") {
					Str = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING'";
				} else {
					string Name = Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%";
					Str = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
				}
				Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Booking);
			} catch (Exception ex) {
				Obj.Pr_ASPNET_MessageBox(ex.Message);
			}
		}

		
        protected void DGrid_View_Booking_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            int i = DGrid_View_Booking.SelectedIndex;
            string StrUp = "UPDATE POST_PAID_BOOKING SET STATUS = 'ISSUED' WHERE POST_PAID_BOOKED_NUM = '" + DGrid_View_Booking.Rows[i].Cells[4].Text + "'";
            SqlCommand Cmd = new SqlCommand(StrUp, Conn);
            Cmd.ExecuteNonQuery();
            Pr_Bind_Users();
            Obj.Pr_ASPNET_MessageBox("Post Paid Card Delivered SuccessFully");
        }
        protected void DGrid_Mob_Shop_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            int i = DGrid_Mob_Shop.SelectedIndex;
            string StrUp = "UPDATE MOB_PHONE_BOOKING SET STATUS = 'DELIVERED' WHERE BOOKING_ID = " + DGrid_Mob_Shop.Rows[i].Cells[0].Text + "";
            SqlCommand Cmd = new SqlCommand(StrUp, Conn);
            Cmd.ExecuteNonQuery();
            Obj.Pr_ASPNET_MessageBox("Mobile phone model delivered SuccessFully");
            Pr_Bind_Grid();
        }
        protected void DGrid_Mob_Shop_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                int i = e.RowIndex;
                string StrDel = "DELETE FROM MOB_PHONE_BOOKING WHERE BOOKING_ID = " + DGrid_Mob_Shop.Rows[i].Cells[0].Text + "";
                SqlCommand Cmd = new SqlCommand(StrDel, Conn);
                Cmd.ExecuteNonQuery();
                Obj.Pr_ASPNET_MessageBox("User's mobile phone registration discarded successfully");
                Pr_Bind_Grid();

            }
            catch (Exception Er)
            {
            }
        }



        protected void DGrid_View_Booking_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                DGrid_View_Booking.PageIndex = e.NewPageIndex;
                string Str = null;
                if (Lbl_PP.Text == "1")
                {
                    Str = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING'";
                }
                else
                {
                    string Name = Strings.Trim(Strings.UCase(Txt_Search_Name.Text)) + "%";
                    Str = "SELECT * FROM POST_PAID_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
                }
                Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Booking);
            }
            catch (Exception ex)
            {
                Obj.Pr_ASPNET_MessageBox(ex.Message);
            }
        }
        protected void DGrid_Mob_Shop_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
try {
				DGrid_Mob_Shop.PageIndex = e.NewPageIndex;
				string Str = null;
				if (Lbl_Mob.Text == "1") {
					Str = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING'";
				} else {
					string Name = Strings.Trim(Strings.UCase(Txt_Mob_Search.Text)) + "%";
					Str = "SELECT * FROM MOB_PHONE_BOOKING WHERE STATUS = 'PENDING' AND USERNAME LIKE '" + Name + "'";
				}
				Obj.Pr_Bind_Grid(Conn, Str, DGrid_View_Booking);
			} catch (Exception ex) {
				Obj.Pr_ASPNET_MessageBox(ex.Message);
			}
		}



        protected void Txt_Mob_Search_TextChanged(object sender, System.EventArgs e)
        {

        }
        
}